import { detectLang } from './i18n.js';

// Language names used inside the AI prompts (the prompts are written in English).
export const LANGUAGES = {
  it: 'Italian',
  en: 'English',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  pt: 'Portuguese',
};

export const PROVIDERS = {
  anthropic: { name: 'Anthropic', defaultModel: 'claude-sonnet-5' },
  openai: { name: 'OpenAI', defaultModel: 'gpt-5.5' },
  gemini: { name: 'Google Gemini', defaultModel: 'gemini-flash-latest' },
};

function defaults() {
  const lang = detectLang();
  return {
    uiLang: lang,
    clientId: '',
    provider: 'anthropic',
    anthropicKey: '',
    anthropicModel: PROVIDERS.anthropic.defaultModel,
    openaiKey: '',
    openaiModel: PROVIDERS.openai.defaultModel,
    geminiKey: '',
    geminiModel: PROVIDERS.gemini.defaultModel,
    language: lang,
    channelContext: '',
    minSize: 4,
    maxSize: 10,
    metric: 'balanced', // pct | duration | balanced
    period: '365', // days or "lifetime"
    minDuration: 60, // skip videos lasting up to this many seconds (0 = skip none)
    onlyPublic: true,
    privacy: 'public',
  };
}

export const DEFAULTS = defaults();

export async function loadSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const merged = { ...defaults(), ...(settings || {}) };
  // Migration from versions up to 1.3: a single "model" field meant the Anthropic model.
  if (settings?.model && !settings.anthropicModel) merged.anthropicModel = settings.model;
  // Users of the Italian-only versions keep Italian as interface language.
  if (settings && !settings.uiLang) merged.uiLang = 'it';
  delete merged.model;
  return merged;
}

export async function saveSettings(settings) {
  await chrome.storage.local.set({ settings });
}

export async function loadPlan() {
  const { plan } = await chrome.storage.local.get('plan');
  return plan || null;
}

export async function savePlan(plan) {
  await chrome.storage.local.set({ plan });
}

export async function clearPlan() {
  await chrome.storage.local.remove('plan');
}

// Playlists the extension may update: { playlistId: { title, channelId, addedAt } }
export async function loadRegistry() {
  const { managed } = await chrome.storage.local.get('managed');
  return managed || {};
}

export async function saveRegistry(managed) {
  await chrome.storage.local.set({ managed });
}
