import {
  DEFAULTS,
  PROVIDERS,
  loadSettings,
  saveSettings,
  loadPlan,
  savePlan,
  clearPlan,
  loadRegistry,
  saveRegistry,
} from './storage.js';
import { getToken, signOut, redirectUri } from './auth.js';
import * as yt from './youtube.js';
import { groupVideos, writeSeo } from './llm.js';
import { buildPlan, sortByScore, matchManaged, planOps } from './planner.js';
import { t, setLang, applyStatic, locale } from './i18n.js';

const $ = (sel) => document.querySelector(sel);
const QUOTA_DAILY = 10000;
const COST_WRITE = 50;

let settings = null;
let plan = null;
let channel = null;
let busy = false;
let saveTimer = null;
let managedOpen = false;

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const cleanText = (s) => String(s ?? '').replace(/[<>]/g, '').trim();
const fmtNum = (n) => Math.round(n ?? 0).toLocaleString(locale());

function fmtDuration(sec) {
  if (sec == null) return '–';
  sec = Math.round(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = String(sec % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

// ---------------------------------------------------------------- startup

init();

async function init() {
  settings = await loadSettings();
  setLang(settings.uiLang);
  $('#uiLang').value = settings.uiLang;
  applyStatic();
  fillForm();
  showProviderFields();
  $('#redirectUri').value = redirectUri();
  if (!settings.clientId || !settings[`${settings.provider}Key`]) $('#credentialsGroup').open = true;
  plan = await loadPlan();
  await registerFromPlan();
  bindEvents();
  refreshTexts();
  if (settings.clientId) {
    try {
      await getToken('silent');
      await loadChannel();
    } catch {
      /* an explicit sign-in is needed */
    }
  }
  updateConnectUi();
}

/** Re-renders every piece of text that depends on the interface language. */
function refreshTexts() {
  applyStatic();
  $('#btnManaged').textContent = t(managedOpen ? 'btn_managed_hide' : 'btn_managed_show');
  updateConnectUi();
  refreshManagedHint();
  render();
}

function bindEvents() {
  $('#uiLang').addEventListener('change', async (e) => {
    setLang(e.target.value);
    settings = { ...(await loadSettings()), uiLang: e.target.value };
    await saveSettings(settings);
    refreshTexts();
  });
  $('#providerSelect').addEventListener('change', showProviderFields);
  $('#settingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    await persistSettings();
    const tag = $('#settingsSaved');
    tag.hidden = false;
    setTimeout(() => (tag.hidden = true), 1800);
  });
  $('#btnCopyRedirect').addEventListener('click', async () => {
    await navigator.clipboard.writeText($('#redirectUri').value);
    $('#btnCopyRedirect').textContent = t('copied');
    setTimeout(() => ($('#btnCopyRedirect').textContent = t('btn_copy')), 1500);
  });
  $('#btnConnect').addEventListener('click', connect);
  $('#btnDisconnect').addEventListener('click', disconnect);
  $('#btnAnalyze').addEventListener('click', analyze);
  $('#btnCreate').addEventListener('click', applyAll);
  $('#btnReset').addEventListener('click', resetPlan);
  $('#btnManaged').addEventListener('click', toggleManagedList);
  $('#managedList').addEventListener('change', onManagedChange);

  const list = $('#playlists');
  list.addEventListener('click', onListClick);
  list.addEventListener('input', onListInput);
  list.addEventListener('change', onListChange);
}

// ---------------------------------------------------------------- settings

function fillForm() {
  const form = $('#settingsForm');
  for (const [key, value] of Object.entries(settings)) {
    const el = form.elements.namedItem(key);
    if (!el) continue;
    if (el.type === 'checkbox') el.checked = !!value;
    else el.value = value;
  }
}

function showProviderFields() {
  const provider = $('#providerSelect').value;
  document.querySelectorAll('.provider-fields').forEach((el) => (el.hidden = el.dataset.provider !== provider));
}

function clampInt(v, min, max, fallback) {
  const n = parseInt(v, 10);
  if (Number.isNaN(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function readForm() {
  const f = $('#settingsForm').elements;
  const next = {
    ...settings,
    clientId: f.clientId.value.trim(),
    provider: f.provider.value,
    anthropicKey: f.anthropicKey.value.trim(),
    anthropicModel: f.anthropicModel.value.trim() || PROVIDERS.anthropic.defaultModel,
    openaiKey: f.openaiKey.value.trim(),
    openaiModel: f.openaiModel.value.trim() || PROVIDERS.openai.defaultModel,
    geminiKey: f.geminiKey.value.trim(),
    geminiModel: f.geminiModel.value.trim() || PROVIDERS.gemini.defaultModel,
    language: f.language.value,
    channelContext: f.channelContext.value.trim(),
    minSize: clampInt(f.minSize.value, 2, 50, DEFAULTS.minSize),
    maxSize: clampInt(f.maxSize.value, 2, 50, DEFAULTS.maxSize),
    metric: f.metric.value,
    period: f.period.value,
    minDuration: clampInt(f.minDuration.value, 0, 3600, DEFAULTS.minDuration),
    onlyPublic: f.onlyPublic.checked,
    privacy: f.privacy.value,
  };
  if (next.maxSize < next.minSize) next.maxSize = next.minSize;
  return next;
}

async function persistSettings() {
  settings = readForm();
  await saveSettings(settings);
  fillForm();
}

// ---------------------------------------------------------------- status and messages

function log(text, kind = 'info') {
  const box = $('#log');
  box.hidden = false;
  const p = document.createElement('p');
  p.className = `log-line ${kind}`;
  p.textContent = text;
  box.appendChild(p);
  box.scrollTop = box.scrollHeight;
  return p;
}

function clearLog() {
  $('#log').innerHTML = '';
}

function setBusy(value) {
  busy = value;
  document.body.classList.toggle('is-busy', value);
  for (const sel of ['#btnConnect', '#btnAnalyze', '#btnCreate', '#btnReset', '#btnDisconnect']) {
    $(sel).disabled = value;
  }
  if (!value) render();
}

function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => savePlan(plan), 300);
}

// ---------------------------------------------------------------- account

async function loadChannel() {
  channel = await yt.getMyChannel();
  const reg = await loadRegistry();
  let changed = false;
  for (const entry of Object.values(reg)) {
    if (!entry.channelId) {
      entry.channelId = channel.id;
      changed = true;
    }
  }
  if (changed) await saveRegistry(reg);
  updateConnectUi();
  refreshManagedHint();
}

function updateConnectUi() {
  const chip = $('#channelChip');
  if (channel) {
    chip.hidden = false;
    chip.innerHTML = `${channel.thumb ? `<img src="${esc(channel.thumb)}" alt="">` : ''}<span>${esc(channel.title)}</span>`;
    $('#connectHint').textContent = t('connect_hint_connected', { name: channel.title });
    $('#btnConnect').hidden = true;
    $('#btnDisconnect').hidden = false;
  } else {
    chip.hidden = true;
    $('#connectHint').textContent = t('connect_hint_default');
    $('#btnConnect').hidden = false;
    $('#btnDisconnect').hidden = true;
  }
}

async function connect() {
  if (busy) return;
  await persistSettings();
  setBusy(true);
  try {
    await getToken('interactive');
    await loadChannel();
  } catch (err) {
    log(err.message, 'error');
  } finally {
    setBusy(false);
  }
}

async function disconnect() {
  await signOut();
  channel = null;
  updateConnectUi();
}

// ---------------------------------------------------------------- managed playlists registry

async function registerPlaylist(id, title) {
  const reg = await loadRegistry();
  reg[id] = { title, channelId: channel?.id || null, addedAt: reg[id]?.addedAt || Date.now() };
  await saveRegistry(reg);
}

/** Recovers playlists created by earlier versions that are still in the saved proposal. */
async function registerFromPlan() {
  if (!plan) return;
  const reg = await loadRegistry();
  let changed = false;
  for (const p of plan.playlists) {
    if (p.createdId && !reg[p.createdId]) {
      reg[p.createdId] = { title: p.title, channelId: channel?.id || null, addedAt: Date.now() };
      changed = true;
    }
  }
  if (changed) await saveRegistry(reg);
}

const belongsToChannel = (entry) => !channel || !entry.channelId || entry.channelId === channel.id;

async function refreshManagedHint() {
  const reg = await loadRegistry();
  const n = Object.values(reg).filter(belongsToChannel).length;
  $('#managedHint').textContent = n ? t('managed_hint_n', { n }) : t('managed_hint_0');
}

async function toggleManagedList() {
  const box = $('#managedBox');
  const btn = $('#btnManaged');
  if (managedOpen) {
    managedOpen = false;
    box.hidden = true;
    btn.textContent = t('btn_managed_show');
    return;
  }
  if (!channel) {
    log(t('err_need_channel_first'), 'error');
    return;
  }
  btn.disabled = true;
  btn.textContent = t('loading');
  try {
    const [all, reg] = await Promise.all([yt.listMyPlaylists(), loadRegistry()]);
    $('#managedList').innerHTML = all.length
      ? all
          .map(
            (pl) => `<label class="check"><input type="checkbox" data-pl="${esc(pl.id)}" data-title="${esc(pl.title)}" ${reg[pl.id] ? 'checked' : ''}>
              <span>${esc(pl.title)} <small>${esc(t('managed_videos', { n: pl.count }))}</small></span></label>`
          )
          .join('')
      : `<p class="hint">${esc(t('managed_empty'))}</p>`;
    managedOpen = true;
    box.hidden = false;
  } catch (err) {
    log(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = t(managedOpen ? 'btn_managed_hide' : 'btn_managed_show');
  }
}

async function onManagedChange(e) {
  const input = e.target.closest('input[data-pl]');
  if (!input) return;
  const reg = await loadRegistry();
  if (input.checked) reg[input.dataset.pl] = { title: input.dataset.title, channelId: channel?.id || null, addedAt: Date.now() };
  else delete reg[input.dataset.pl];
  await saveRegistry(reg);
  refreshManagedHint();
}

// ---------------------------------------------------------------- analysis

const seoInput = (p) => ({
  key: p.key,
  theme: p.theme,
  summary: p.summary,
  videos: p.videos.map((id) => plan.videosById[id]?.title).filter(Boolean),
});

function applySeo(results) {
  for (const r of results) {
    const p = plan.playlists.find((x) => x.key === r.key);
    if (!p || isLocked(p)) continue;
    if (r.title) p.title = cleanText(r.title).slice(0, 150);
    if (r.description) p.description = cleanText(r.description).slice(0, 5000);
  }
}

async function analyze() {
  if (busy) return;
  await persistSettings();
  if (!settings[`${settings.provider}Key`]) {
    $('#credentialsGroup').open = true;
    log(t('err_need_key', { provider: PROVIDERS[settings.provider].name }), 'error');
    return;
  }
  if (plan && !confirm(t('confirm_replace'))) return;

  setBusy(true);
  clearLog();
  try {
    if (!channel) {
      await getToken('interactive');
      await loadChannel();
    }

    const step1 = log(t('log_uploads'));
    const ids = await yt.listUploadIds(channel.uploadsId, (n) => (step1.textContent = t('log_uploads_n', { n })));
    step1.textContent = t('log_uploads_done', { n: ids.length });

    const step2 = log(t('log_details'));
    let videos = await yt.getVideos(ids, (n) => (step2.textContent = t('log_details_n', { n, total: ids.length })));
    const total = videos.length;
    videos = videos.filter(
      (v) => (!settings.onlyPublic || v.privacy === 'public') && (settings.minDuration <= 0 || v.durationSec > settings.minDuration)
    );
    step2.textContent = t('log_filtered', { kept: videos.length, skipped: total - videos.length });
    if (videos.length < settings.minSize) throw new Error(t('err_not_enough'));

    const step3 = log(t('log_metrics'));
    const metrics = await yt.getRetention(
      videos.map((v) => v.id),
      settings.period,
      channel.publishedAt
    );
    step3.textContent = t('log_metrics_done', { n: metrics.size, total: videos.length });

    const step4 = log(t('log_grouping'));
    const themes = await groupVideos(settings, videos, (msg) => (step4.textContent = msg));
    step4.textContent = t('log_themes_done', { n: themes.length });

    plan = buildPlan(themes, videos, metrics, settings);
    plan.extraTitles = {};
    plan.unmatchedManaged = [];

    const reg = await loadRegistry();
    const managedIds = Object.keys(reg).filter((id) => belongsToChannel(reg[id]));
    if (managedIds.length) {
      const stepM = log(t('log_matching'));
      const found = await yt.getPlaylistsByIds(managedIds);
      const foundIds = new Set(found.map((f) => f.id));
      for (const id of managedIds) if (!foundIds.has(id)) delete reg[id]; // deleted on YouTube
      await saveRegistry(reg);
      for (const f of found) {
        f.items = await yt.listPlaylistItems(f.id);
        for (const it of f.items) {
          if (!plan.videosById[it.videoId]) plan.extraTitles[it.videoId] = it.title;
        }
      }
      plan.unmatchedManaged = matchManaged(plan.playlists, found);
      const upd = plan.playlists.filter(isUpdate).length;
      stepM.textContent = t('log_matching_done', { upd, nw: plan.playlists.length - upd });
      refreshManagedHint();
    }

    if (plan.playlists.length) {
      const step5 = log(t('log_seo'));
      applySeo(await writeSeo(settings, plan.playlists.map(seoInput)));
      step5.textContent = t('log_seo_done');
    } else {
      log(t('warn_no_themes', { n: settings.minSize }), 'warn');
    }

    try {
      plan.existingTitles = await yt.listMyPlaylistTitles();
    } catch {
      plan.existingTitles = [];
    }

    await savePlan(plan);
    log(t('log_ready'), 'ok');
  } catch (err) {
    log(err.message, 'error');
  } finally {
    setBusy(false);
  }
}

// ---------------------------------------------------------------- preview

const isUpdate = (p) => p.mode === 'update';
const isLocked = (p) => (isUpdate(p) ? !!p.done : !!p.createdId);
const canEditText = (p) => !isLocked(p) && (!isUpdate(p) || p.updateText);
const titleOf = (id) => plan.videosById[id]?.title || plan.extraTitles?.[id] || id;

function diffOf(p) {
  const items = (p.existingItems || []).map((videoId, i) => ({ itemId: `e${i}`, videoId }));
  const ops = planOps(items, p.videos);
  const existing = new Set(p.existingItems || []);
  const target = new Set(p.videos);
  return {
    added: p.videos.filter((v) => !existing.has(v)),
    removed: [...existing].filter((v) => !target.has(v)),
    moves: ops.ops.filter((o) => o.type === 'move').length,
    cost: ops.cost + (p.updateText && !p.textDone ? COST_WRITE : 0),
  };
}

function costFor(p) {
  if (isUpdate(p)) return p.done ? 0 : diffOf(p).cost;
  return (p.createdId ? 0 : COST_WRITE) + COST_WRITE * Math.max(0, p.videos.length - (p.addedCount || 0));
}

const pending = (p) => p.include && costFor(p) > 0;
const quotaFor = (list) => list.reduce((q, p) => q + costFor(p), 0);

function render() {
  const has = !!plan;
  $('#empty').hidden = has;
  $('#preview').hidden = !has;
  if (!has) return;

  renderSummary();
  $('#playlists').innerHTML = plan.playlists.length
    ? plan.playlists.map(renderPlaylist).join('')
    : `<p class="hint">${esc(t('no_playlists'))}</p>`;
  renderExcluded();
}

function renderSummary() {
  const included = plan.playlists.filter((p) => p.include);
  const todo = plan.playlists.filter(pending);
  const videos = included.reduce((n, p) => n + p.videos.length, 0);
  const quota = quotaFor(todo);
  const nUpd = included.filter(isUpdate).length;

  let text = t('summary', { sel: included.length, total: plan.playlists.length, nNew: included.length - nUpd, nUpd, videos });
  if (todo.length) {
    text += t('summary_quota', { q: fmtNum(quota), daily: fmtNum(QUOTA_DAILY) });
    if (quota > QUOTA_DAILY) text += t('summary_quota_over');
  }
  const unmatched = plan.unmatchedManaged?.length || 0;
  if (unmatched) text += t('summary_unmatched', { n: unmatched });
  $('#summary').textContent = text;

  const partial = plan.playlists.some(
    (p) => p.include && ((p.createdId && p.addedCount < p.videos.length) || (isUpdate(p) && p.textDone && !p.done))
  );
  const btn = $('#btnCreate');
  btn.textContent = t(partial ? 'btn_resume' : nUpd ? 'btn_apply' : 'btn_create');
  btn.disabled = busy || !todo.length;
}

function counterInfo(field, value) {
  if (field === 'title') return { text: t('counter_title', { n: value.length }), warn: value.length > 70 || !value.trim() };
  return { text: t('counter_desc', { n: value.length }), warn: value.length < 300 || value.length > 1500 };
}

const isDuplicate = (p) =>
  !isUpdate(p) && !p.createdId && (plan.existingTitles || []).includes(p.title.trim().toLowerCase());

function renderPlaylist(p) {
  const byId = plan.videosById;
  const locked = isLocked(p);
  const update = isUpdate(p);
  const dis = locked ? 'disabled' : '';
  const diff = update ? diffOf(p) : null;
  const existing = new Set(p.existingItems || []);

  let status;
  if (update) {
    const link = `https://www.youtube.com/playlist?list=${esc(p.targetId)}`;
    status = p.done
      ? `<a class="badge ok" href="${link}" target="_blank" rel="noopener">${esc(t('badge_updated'))}</a>`
      : `<a class="badge info" href="${link}" target="_blank" rel="noopener">${esc(t('badge_update'))}</a>`;
  } else if (p.createdId && p.addedCount >= p.videos.length) {
    status = `<a class="badge ok" href="https://www.youtube.com/playlist?list=${esc(p.createdId)}" target="_blank" rel="noopener">${esc(t('badge_created'))}</a>`;
  } else if (p.createdId) {
    status = `<span class="badge warn">${esc(t('badge_partial', { a: p.addedCount, b: p.videos.length }))}</span>`;
  } else {
    status = `<span class="badge new">${esc(t('badge_new'))}</span>`;
  }

  const notes = [];
  if (p.videos.length < settings.minSize) notes.push(t('note_below_min', { n: settings.minSize }));
  if (p.videos.length > settings.maxSize) notes.push(t('note_above_max', { n: settings.maxSize }));

  // ---- text
  const tc = counterInfo('title', p.title);
  const dc = counterInfo('description', p.description);
  const editable = `
    <label class="field">
      <span>${esc(t(update ? 'f_new_title' : 'f_title'))}</span>
      <input type="text" data-field="title" maxlength="150" value="${esc(p.title)}" ${dis}>
      <small data-counter="title" class="${tc.warn ? 'warn' : ''}">${esc(tc.text)}</small>
      <small data-dup class="warn" ${isDuplicate(p) ? '' : 'hidden'}>${esc(t('dup_title'))}</small>
    </label>
    <label class="field">
      <span>${esc(t(update ? 'f_new_desc' : 'f_desc'))}</span>
      <textarea data-field="description" maxlength="5000" rows="9" ${dis}>${esc(p.description)}</textarea>
      <small data-counter="description" class="${dc.warn ? 'warn' : ''}">${esc(dc.text)}</small>
    </label>
    ${locked ? '' : `<button class="btn small ghost" data-action="regen" type="button">${esc(t('btn_regen'))}</button>`}`;

  let textHtml;
  if (!update) {
    textHtml = editable;
  } else {
    const desc = p.existingDescription
      ? esc(p.existingDescription.length > 400 ? `${p.existingDescription.slice(0, 400)}…` : p.existingDescription)
      : `<em>${esc(t('no_desc'))}</em>`;
    textHtml = `
      <div class="current-text">
        <span class="lbl">${esc(t('cur_title'))}</span><p class="cur-title">${esc(p.existingTitle)}</p>
        <span class="lbl">${esc(t('cur_desc'))}</span><p>${desc}</p>
      </div>
      <label class="check"><input type="checkbox" data-action="updtext" ${p.updateText ? 'checked' : ''} ${dis}>
        <span>${esc(t('chk_update_text'))}</span></label>
      ${p.updateText ? editable : `<p class="hint">${esc(t('keep_text_note'))}</p>`}`;
  }

  // ---- videos
  const rows = p.videos
    .map((id, i) => {
      const v = byId[id];
      if (!v) return '';
      const width = v.pct != null ? Math.min(100, v.pct) : 0;
      const meta =
        v.pct != null
          ? t('vid_meta', { pct: v.pct.toFixed(0), dur: fmtDuration(v.dur), len: fmtDuration(v.durationSec), views: fmtNum(v.views) })
          : t('vid_meta_nodata', { views: fmtNum(v.views) });
      const isNew = update && !existing.has(id);
      const actions = locked
        ? ''
        : `<div class="vid-actions">
            <button class="icon" data-action="up" data-i="${i}" ${i === 0 ? 'disabled' : ''} aria-label="${esc(t('aria_up'))}" title="${esc(t('aria_up'))}">↑</button>
            <button class="icon" data-action="down" data-i="${i}" ${i === p.videos.length - 1 ? 'disabled' : ''} aria-label="${esc(t('aria_down'))}" title="${esc(t('aria_down'))}">↓</button>
            <button class="icon danger" data-action="remove" data-i="${i}" aria-label="${esc(t('aria_remove'))}" title="${esc(t('aria_remove'))}">×</button>
          </div>`;
      return `<li class="vid ${i === 0 ? 'lead' : ''}">
        <span class="rank">${i + 1}</span>
        ${v.thumb ? `<img src="${esc(v.thumb)}" alt="" loading="lazy">` : '<span class="thumb-ph"></span>'}
        <div class="vid-main">
          <div class="title-line">${isNew ? `<span class="chip">${esc(t('chip_new'))}</span>` : ''}<a href="https://www.youtube.com/watch?v=${esc(id)}" target="_blank" rel="noopener">${esc(v.title)}</a></div>
          <div class="meter" aria-hidden="true"><span style="width:${width}%"></span></div>
          <div class="vid-meta">${esc(meta)}</div>
        </div>
        ${actions}
      </li>`;
    })
    .join('');

  let headLine = esc(t('head_count', { n: p.videos.length }));
  if (update && !p.done) {
    const parts = [];
    if (diff.added.length) parts.push(t('diff_add', { n: diff.added.length }));
    if (diff.removed.length) parts.push(t('diff_remove', { n: diff.removed.length }));
    if (diff.moves) parts.push(t('diff_moves', { n: diff.moves }));
    headLine = `<span class="diff">${esc(parts.length ? parts.join(', ') : t('diff_none'))}</span>`;
  }

  const removed =
    update && !p.done && diff.removed.length
      ? `<div class="removed"><p>${esc(t('removed_title'))}</p>
          <ul>${diff.removed.map((id) => `<li>${esc(titleOf(id))}</li>`).join('')}</ul></div>`
      : '';

  const reserve =
    !locked && p.reserve.length
      ? `<details class="reserve">
          <summary>${esc(t('reserve_summary', { n: p.reserve.length }))}</summary>
          <ul>${p.reserve
            .map((id) => {
              const v = byId[id];
              if (!v) return '';
              const pct = v.pct != null ? `${v.pct.toFixed(0)}%` : 'n/a';
              return `<li><span class="r-pct">${pct}</span><span class="r-title">${esc(v.title)}</span><button class="btn small" data-action="add" data-id="${esc(id)}">${esc(t('btn_add'))}</button></li>`;
            })
            .join('')}</ul>
        </details>`
      : '';

  return `<article class="pl ${p.include ? '' : 'off'} ${locked ? 'locked' : ''}" data-key="${esc(p.key)}">
    <div class="pl-head">
      <label class="check"><input type="checkbox" data-action="toggle" ${p.include ? 'checked' : ''} ${dis}><span>${esc(t('include'))}</span></label>
      <span class="theme">${esc(p.theme)}</span>
      ${status}
    </div>
    <div class="pl-body">
      <div class="pl-text">${textHtml}</div>
      <div class="pl-videos">
        <div class="pl-videos-head">
          <span>${headLine}</span>
          ${locked ? '' : `<button class="link" data-action="resort" type="button">${esc(t('btn_resort'))}</button>`}
        </div>
        ${notes.length ? `<p class="note">${esc(notes.join(' '))}</p>` : ''}
        <ol class="vids">${rows}</ol>
        ${removed}
        ${reserve}
      </div>
    </div>
  </article>`;
}

function excludedName(e) {
  return e.unassigned ? t('excl_unassigned') : e.theme;
}

function excludedReason(e) {
  if (typeof e.reason === 'string') return e.reason; // proposals saved by older versions
  if (e.reason?.type === 'belowMin') return t('excl_below_min', { n: e.reason.n, min: e.reason.min });
  return t('excl_count', { n: e.reason?.n ?? e.videos.length });
}

function renderExcluded() {
  const box = $('#excludedBox');
  if (!plan.excluded?.length) {
    box.hidden = true;
    return;
  }
  box.hidden = false;
  const count = plan.excluded.reduce((n, e) => n + e.videos.length, 0);
  $('#excludedSummary').textContent = t('excluded_summary', { g: plan.excluded.length, v: count });
  $('#excluded').innerHTML = plan.excluded
    .map(
      (e) => `<div class="ex">
        <h3>${esc(excludedName(e))} <span>${esc(excludedReason(e))}</span></h3>
        <ul>${e.videos.map((id) => `<li>${esc(titleOf(id))}</li>`).join('')}</ul>
      </div>`
    )
    .join('');
}

// ---------------------------------------------------------------- edits

function playlistFrom(el) {
  const card = el.closest('[data-key]');
  return card ? plan.playlists.find((p) => p.key === card.dataset.key) : null;
}

function onListClick(e) {
  const btn = e.target.closest('button[data-action]');
  if (!btn || busy) return;
  const p = playlistFrom(btn);
  if (!p || isLocked(p)) return;
  const i = Number(btn.dataset.i);

  switch (btn.dataset.action) {
    case 'up':
      [p.videos[i - 1], p.videos[i]] = [p.videos[i], p.videos[i - 1]];
      break;
    case 'down':
      [p.videos[i + 1], p.videos[i]] = [p.videos[i], p.videos[i + 1]];
      break;
    case 'remove': {
      const [id] = p.videos.splice(i, 1);
      p.reserve = sortByScore([...p.reserve, id], plan.videosById, plan.metric);
      break;
    }
    case 'add':
      p.reserve = p.reserve.filter((id) => id !== btn.dataset.id);
      p.videos.push(btn.dataset.id);
      break;
    case 'resort':
      p.videos = sortByScore(p.videos, plan.videosById, plan.metric);
      break;
    case 'regen':
      regenerate(p, btn);
      return;
    default:
      return;
  }
  persist();
  render();
}

function onListInput(e) {
  const field = e.target.dataset.field;
  if (!field) return;
  const p = playlistFrom(e.target);
  if (!p || !canEditText(p)) return;
  p[field] = e.target.value;
  const card = e.target.closest('[data-key]');
  const info = counterInfo(field, e.target.value);
  const counter = card.querySelector(`[data-counter="${field}"]`);
  counter.textContent = info.text;
  counter.classList.toggle('warn', info.warn);
  if (field === 'title') card.querySelector('[data-dup]').hidden = !isDuplicate(p);
  persist();
}

function onListChange(e) {
  const action = e.target.dataset.action;
  if (action !== 'toggle' && action !== 'updtext') return;
  const p = playlistFrom(e.target);
  if (!p || isLocked(p)) return;
  if (action === 'toggle') p.include = e.target.checked;
  else p.updateText = e.target.checked;
  persist();
  render();
}

async function regenerate(p, btn) {
  settings = await loadSettings();
  btn.disabled = true;
  btn.textContent = t('regen_busy');
  try {
    applySeo(await writeSeo(settings, [seoInput(p)]));
    await savePlan(plan);
    render();
  } catch (err) {
    log(err.message, 'error');
    btn.disabled = false;
    btn.textContent = t('btn_regen');
  }
}

async function resetPlan() {
  if (!plan || busy) return;
  if (!confirm(t('confirm_discard'))) return;
  await clearPlan();
  plan = null;
  render();
}

// ---------------------------------------------------------------- applying on YouTube

async function applyAll() {
  if (busy || !plan) return;
  settings = await loadSettings();
  const todo = plan.playlists.filter(pending);
  if (!todo.length) return;

  const empty = todo.find((p) => canEditText(p) && !cleanText(p.title));
  if (empty) {
    log(t('err_no_title', { theme: empty.theme }), 'error');
    return;
  }

  const nUpd = todo.filter(isUpdate).length;
  const ok = confirm(
    t('confirm_apply', { nNew: todo.length - nUpd, nUpd, q: fmtNum(quotaFor(todo)), daily: fmtNum(QUOTA_DAILY) })
  );
  if (!ok) return;

  setBusy(true);
  clearLog();
  try {
    if (!channel) await loadChannel();
    for (const p of todo) {
      if (isUpdate(p)) await applyUpdate(p);
      else await applyCreate(p);
    }
    log(t('log_all_done'), 'ok');
  } catch (err) {
    log(err.message, 'error');
    if (yt.isQuotaError(err)) log(t('log_quota_resume'), 'warn');
  } finally {
    await savePlan(plan);
    refreshManagedHint();
    setBusy(false);
  }
}

async function applyCreate(p) {
  const title = cleanText(p.title);
  const line = log(t('log_creating', { title }));
  if (!p.createdId) {
    const created = await yt.createPlaylist({
      title: title.slice(0, 150),
      description: cleanText(p.description).slice(0, 5000),
      privacy: settings.privacy,
      language: settings.language,
    });
    p.createdId = created.id;
    p.addedCount = 0;
    await registerPlaylist(created.id, title);
    await savePlan(plan);
  }
  for (let i = p.addedCount; i < p.videos.length; i++) {
    line.textContent = t('log_creating_n', { title, i: i + 1, n: p.videos.length });
    await yt.addToPlaylist(p.createdId, p.videos[i], i);
    p.addedCount = i + 1;
    await savePlan(plan);
  }
  line.textContent = t('log_created', { title, n: p.videos.length });
  line.className = 'log-line ok';
}

async function applyUpdate(p) {
  const title = p.updateText ? cleanText(p.title) : p.existingTitle;
  const line = log(t('log_updating', { title }));

  if (p.updateText && !p.textDone) {
    await yt.updatePlaylistText(p.targetId, {
      title: cleanText(p.title).slice(0, 150),
      description: cleanText(p.description).slice(0, 5000),
      language: settings.language,
    });
    p.textDone = true;
    await registerPlaylist(p.targetId, cleanText(p.title));
    await savePlan(plan);
  }

  // Always start from the real state on YouTube, so resuming after an interruption is safe.
  const items = await yt.listPlaylistItems(p.targetId);
  const { deletes, ops } = planOps(items, p.videos);
  const total = deletes.length + ops.length;
  let n = 0;
  for (const d of deletes) {
    line.textContent = t('log_updating_n', { title, i: ++n, n: total });
    await yt.deletePlaylistItem(d.itemId);
  }
  for (const op of ops) {
    line.textContent = t('log_updating_n', { title, i: ++n, n: total });
    if (op.type === 'move') await yt.movePlaylistItem(p.targetId, op.itemId, op.videoId, op.position);
    else await yt.addToPlaylist(p.targetId, op.videoId, op.position);
  }

  p.done = true;
  p.existingItems = [...p.videos];
  await savePlan(plan);
  line.textContent = total ? t('log_updated', { title, n: total }) : t('log_already', { title });
  line.className = 'log-line ok';
}
