import { getToken, invalidateToken } from './auth.js';
import { t } from './i18n.js';

const API = 'https://www.googleapis.com/youtube/v3';
const ANALYTICS = 'https://youtubeanalytics.googleapis.com/v2/reports';

// YouTube error reasons mapped to translation keys
const REASONS = {
  quotaExceeded: 'yt_quota',
  dailyLimitExceeded: 'yt_quota',
  forbidden: 'yt_forbidden',
  insufficientPermissions: 'yt_insufficient',
  accessNotConfigured: 'yt_api_disabled',
  SERVICE_DISABLED: 'yt_api_disabled',
  playlistTitleRequired: 'yt_title_required',
  invalidPlaylistSnippet: 'yt_invalid_snippet',
  playlistNotFound: 'yt_playlist_not_found',
  playlistItemNotFound: 'yt_item_not_found',
  videoNotFound: 'yt_video_not_found',
};

export class ApiError extends Error {
  constructor(message, reason, status) {
    super(message);
    this.reason = reason;
    this.status = status;
  }
}

export const isQuotaError = (err) => err?.reason === 'quotaExceeded' || err?.reason === 'dailyLimitExceeded';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const qs = (params) => new URLSearchParams(params).toString();

async function call(url, { method = 'GET', body } = {}, attempt = 0) {
  const token = await getToken('auto');
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.ok) return res.status === 204 ? null : res.json();

  let data = null;
  try {
    data = await res.json();
  } catch {
    /* response without a JSON body */
  }
  const reason = data?.error?.errors?.[0]?.reason || data?.error?.status;

  if (res.status === 401 && attempt === 0) {
    await invalidateToken();
    return call(url, { method, body }, 1);
  }
  // YouTube sometimes returns temporary 409/5xx errors on rapid consecutive inserts
  if ([409, 500, 503].includes(res.status) && attempt < 3) {
    await sleep(1500 * (attempt + 1));
    return call(url, { method, body }, attempt + 1);
  }
  const message = REASONS[reason]
    ? t(REASONS[reason])
    : t('yt_generic', { status: res.status, msg: data?.error?.message || res.statusText });
  throw new ApiError(message, reason, res.status);
}

function parseDuration(iso) {
  const m = /^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/.exec(iso || '');
  if (!m) return 0;
  return (+m[1] || 0) * 86400 + (+m[2] || 0) * 3600 + (+m[3] || 0) * 60 + (+m[4] || 0);
}

function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

const isoDate = (d) => d.toISOString().slice(0, 10);

export async function getMyChannel() {
  const data = await call(`${API}/channels?${qs({ part: 'snippet,contentDetails', mine: 'true' })}`);
  const c = data.items?.[0];
  if (!c) {
    throw new Error(t('yt_no_channel'));
  }
  return {
    id: c.id,
    title: c.snippet.title,
    thumb: c.snippet.thumbnails?.default?.url || '',
    publishedAt: c.snippet.publishedAt,
    uploadsId: c.contentDetails.relatedPlaylists.uploads,
  };
}

export async function listUploadIds(uploadsId, onProgress) {
  const ids = [];
  let pageToken;
  do {
    const params = { part: 'contentDetails', playlistId: uploadsId, maxResults: '50' };
    if (pageToken) params.pageToken = pageToken;
    const data = await call(`${API}/playlistItems?${qs(params)}`);
    for (const item of data.items || []) ids.push(item.contentDetails.videoId);
    pageToken = data.nextPageToken;
    onProgress?.(ids.length);
  } while (pageToken);
  return [...new Set(ids)];
}

export async function getVideos(ids, onProgress) {
  const videos = [];
  for (const group of chunk(ids, 50)) {
    const data = await call(
      `${API}/videos?${qs({ part: 'snippet,contentDetails,status,statistics', id: group.join(','), maxResults: '50' })}`
    );
    for (const v of data.items || []) {
      const t = v.snippet.thumbnails || {};
      videos.push({
        id: v.id,
        title: v.snippet.title,
        description: v.snippet.description || '',
        tags: v.snippet.tags || [],
        thumb: t.medium?.url || t.default?.url || '',
        durationSec: parseDuration(v.contentDetails?.duration),
        privacy: v.status?.privacyStatus,
        views: Number(v.statistics?.viewCount || 0),
        publishedAt: v.snippet.publishedAt,
      });
    }
    onProgress?.(videos.length);
  }
  return videos;
}

/** Returns a Map videoId -> { views, dur, pct } for the chosen period. */
export async function getRetention(ids, period, channelPublishedAt) {
  const endDate = isoDate(new Date());
  let startDate;
  if (period === 'lifetime') {
    startDate = (channelPublishedAt || '2005-04-23').slice(0, 10);
  } else {
    const d = new Date();
    d.setDate(d.getDate() - Number(period));
    startDate = isoDate(d);
  }

  const result = new Map();
  for (const group of chunk(ids, 200)) {
    const data = await call(
      `${ANALYTICS}?${qs({
        ids: 'channel==MINE',
        startDate,
        endDate,
        metrics: 'views,averageViewDuration,averageViewPercentage',
        dimensions: 'video',
        filters: `video==${group.join(',')}`,
        maxResults: '200',
        sort: '-views',
      })}`
    );
    const cols = (data.columnHeaders || []).map((h) => h.name);
    const iVideo = cols.indexOf('video');
    const iViews = cols.indexOf('views');
    const iDur = cols.indexOf('averageViewDuration');
    const iPct = cols.indexOf('averageViewPercentage');
    for (const row of data.rows || []) {
      result.set(row[iVideo], { views: Number(row[iViews]), dur: Number(row[iDur]), pct: Number(row[iPct]) });
    }
  }
  return result;
}

export async function listMyPlaylists() {
  const out = [];
  let pageToken;
  do {
    const params = { part: 'snippet,contentDetails', mine: 'true', maxResults: '50' };
    if (pageToken) params.pageToken = pageToken;
    const data = await call(`${API}/playlists?${qs(params)}`);
    for (const p of data.items || []) {
      out.push({ id: p.id, title: p.snippet.title, count: p.contentDetails?.itemCount ?? 0 });
    }
    pageToken = data.nextPageToken;
  } while (pageToken);
  return out;
}

export async function listMyPlaylistTitles() {
  return (await listMyPlaylists()).map((p) => p.title.trim().toLowerCase());
}

/** Title and description of the given playlists (playlists deleted on YouTube are missing from the result). */
export async function getPlaylistsByIds(ids) {
  const out = [];
  for (const group of chunk(ids, 50)) {
    const data = await call(`${API}/playlists?${qs({ part: 'snippet', id: group.join(','), maxResults: '50' })}`);
    for (const p of data.items || []) {
      out.push({ id: p.id, title: p.snippet.title, description: p.snippet.description || '' });
    }
  }
  return out;
}

/** Playlist items in order: [{ itemId, videoId, title }] */
export async function listPlaylistItems(playlistId) {
  const items = [];
  let pageToken;
  do {
    const params = { part: 'snippet', playlistId, maxResults: '50' };
    if (pageToken) params.pageToken = pageToken;
    const data = await call(`${API}/playlistItems?${qs(params)}`);
    for (const it of data.items || []) {
      items.push({
        itemId: it.id,
        videoId: it.snippet.resourceId?.videoId,
        title: it.snippet.title,
        position: it.snippet.position,
      });
    }
    pageToken = data.nextPageToken;
  } while (pageToken);
  return items.filter((i) => i.videoId).sort((a, b) => a.position - b.position);
}

export async function updatePlaylistText(playlistId, { title, description, language }) {
  return call(`${API}/playlists?${qs({ part: 'snippet' })}`, {
    method: 'PUT',
    body: { id: playlistId, snippet: { title, description, defaultLanguage: language } },
  });
}

export async function movePlaylistItem(playlistId, itemId, videoId, position) {
  return call(`${API}/playlistItems?${qs({ part: 'snippet' })}`, {
    method: 'PUT',
    body: { id: itemId, snippet: { playlistId, position, resourceId: { kind: 'youtube#video', videoId } } },
  });
}

/** Removes a video from the playlist (the video stays on the channel). */
export async function deletePlaylistItem(itemId) {
  return call(`${API}/playlistItems?${qs({ id: itemId })}`, { method: 'DELETE' });
}

export async function createPlaylist({ title, description, privacy, language }) {
  return call(`${API}/playlists?${qs({ part: 'snippet,status' })}`, {
    method: 'POST',
    body: {
      snippet: { title, description, defaultLanguage: language },
      status: { privacyStatus: privacy },
    },
  });
}

export async function addToPlaylist(playlistId, videoId, position) {
  return call(`${API}/playlistItems?${qs({ part: 'snippet' })}`, {
    method: 'POST',
    body: {
      snippet: { playlistId, position, resourceId: { kind: 'youtube#video', videoId } },
    },
  });
}
