import { LANGUAGES, PROVIDERS } from './storage.js';
import { t } from './i18n.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

class TruncatedError extends Error {
  constructor() {
    super('truncated');
    this.truncated = true;
  }
}

const providerName = (settings) => PROVIDERS[settings.provider]?.name || 'AI';
const keyOf = (settings) => settings[`${settings.provider}Key`];
const modelOf = (settings) => settings[`${settings.provider}Model`] || PROVIDERS[settings.provider]?.defaultModel;

async function safeJson(res) {
  try {
    return await res.json();
  } catch {
    return null;
  }
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

// ------------------------------------------------------------------ schema adapters

/** OpenAI strict mode: every object needs additionalProperties:false and all properties required. */
function strictSchema(schema) {
  const s = { ...schema };
  if (s.type === 'object' && s.properties) {
    s.properties = Object.fromEntries(Object.entries(s.properties).map(([k, v]) => [k, strictSchema(v)]));
    s.required = Object.keys(s.properties);
    s.additionalProperties = false;
  }
  if (s.type === 'array' && s.items) s.items = strictSchema(s.items);
  return s;
}

/** Gemini responseSchema: OpenAPI subset with upper-case types. */
function geminiSchema(schema) {
  const s = { type: schema.type.toUpperCase() };
  if (schema.description) s.description = schema.description;
  if (schema.properties) {
    s.properties = Object.fromEntries(Object.entries(schema.properties).map(([k, v]) => [k, geminiSchema(v)]));
    s.propertyOrdering = Object.keys(schema.properties);
  }
  if (schema.required) s.required = schema.required;
  if (schema.items) s.items = geminiSchema(schema.items);
  return s;
}

// ------------------------------------------------------------------ error classification

function classify(settings, status, data, phase) {
  const provider = providerName(settings);
  const msg = data?.error?.message || '';
  const code = String(data?.error?.code || data?.error?.status || data?.error?.type || '');

  if (status === 401 || /invalid_api_key|API_KEY_INVALID/i.test(code) || (status === 400 && /api key/i.test(msg))) {
    return { message: t('llm_bad_key', { provider }) };
  }
  if (status === 403 && settings.provider === 'gemini') return { message: t('llm_bad_key', { provider }) };
  if (status === 404 || code === 'model_not_found') return { message: t('llm_model_not_found', { model: modelOf(settings) }) };
  if (code === 'insufficient_quota' || /credit balance/i.test(msg)) return { message: t('llm_no_credit', { provider }) };
  if (status === 429 || status === 529 || status >= 500) {
    return { retry: true, message: status === 429 ? t('llm_rate', { provider }) : t('llm_error', { phase, status, msg }) };
  }
  return { message: t('llm_error', { phase, status, msg: msg || String(status) }) };
}

// ------------------------------------------------------------------ provider calls
// Each call returns { result } | { truncated } | { refused } | { error: { message, retry } }

async function callAnthropic(settings, req) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': keyOf(settings),
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: modelOf(settings),
      max_tokens: req.maxTokens,
      system: req.system,
      tools: [{ name: 'result', description: 'Returns the requested result.', input_schema: req.schema }],
      tool_choice: { type: 'tool', name: 'result' },
      messages: [{ role: 'user', content: req.prompt }],
    }),
  });
  const data = await safeJson(res);
  if (!res.ok) return { error: classify(settings, res.status, data, req.phase) };
  if (data?.stop_reason === 'max_tokens') return { truncated: true };
  if (data?.stop_reason === 'refusal') return { refused: true };
  const block = (data?.content || []).find((b) => b.type === 'tool_use');
  return { result: block?.input || null };
}

async function callOpenAI(settings, req) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${keyOf(settings)}` },
    body: JSON.stringify({
      model: modelOf(settings),
      // reasoning models spend part of the budget thinking, so leave headroom
      max_completion_tokens: req.maxTokens + 16000,
      messages: [
        { role: 'system', content: req.system },
        { role: 'user', content: req.prompt },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: { name: 'result', strict: true, schema: strictSchema(req.schema) },
      },
    }),
  });
  const data = await safeJson(res);
  if (!res.ok) return { error: classify(settings, res.status, data, req.phase) };
  const choice = data?.choices?.[0];
  if (!choice) return { result: null };
  if (choice.finish_reason === 'length') return { truncated: true };
  if (choice.message?.refusal) return { refused: true };
  return { result: parseJson(choice.message?.content || '') };
}

async function callGemini(settings, req) {
  const model = modelOf(settings);
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': keyOf(settings) },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: req.system }] },
        contents: [{ role: 'user', parts: [{ text: req.prompt }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: geminiSchema(req.schema),
          // thinking models spend part of the budget reasoning, so leave headroom
          maxOutputTokens: req.maxTokens + 16000,
        },
      }),
    }
  );
  const data = await safeJson(res);
  if (!res.ok) return { error: classify(settings, res.status, data, req.phase) };
  const cand = data?.candidates?.[0];
  if (!cand) return data?.promptFeedback?.blockReason ? { refused: true } : { result: null };
  if (cand.finishReason === 'MAX_TOKENS') return { truncated: true };
  if (['SAFETY', 'RECITATION', 'PROHIBITED_CONTENT', 'BLOCKLIST', 'SPII'].includes(cand.finishReason)) return { refused: true };
  const text = (cand.content?.parts || [])
    .filter((p) => p.text && !p.thought)
    .map((p) => p.text)
    .join('');
  return { result: parseJson(text) };
}

const CALLS = { anthropic: callAnthropic, openai: callOpenAI, gemini: callGemini };

/**
 * Asks the selected model to fill in a structured schema, so the data arrives already decoded.
 * `valid` checks the result has the expected shape; invalid results are retried up to twice.
 */
async function ask(settings, req) {
  if (!keyOf(settings)) throw new Error(t('llm_no_key', { provider: providerName(settings) }));
  const call = CALLS[settings.provider] || callAnthropic;

  for (let attempt = 0; attempt < 3; attempt++) {
    const out = await call(settings, req);
    if (out.error) {
      if (out.error.retry && attempt < 2) {
        await sleep(4000 * (attempt + 1));
        continue;
      }
      throw new Error(out.error.message);
    }
    if (out.truncated) throw new TruncatedError();
    if (out.refused) throw new Error(t('llm_refused', { phase: req.phase }));
    if (out.result && req.valid(out.result)) return out.result;
  }
  throw new Error(t('llm_bad_format', { phase: req.phase }));
}

const oneLine = (s, max) =>
  String(s || '')
    .replace(/https?:\/\/\S+/g, '')
    .replace(/\s+/g, ' ')
    .replace(/\|/g, '/')
    .trim()
    .slice(0, max);

// ------------------------------------------------------------------ grouping

const SYSTEM_THEMES =
  "You are a YouTube content strategist. You organize a channel's videos into broad topics that work as playlists a viewer would watch back to back.";

const THEMES_SCHEMA = {
  type: 'object',
  properties: {
    themes: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          name: { type: 'string', description: 'Short topic name, at most 6 words' },
          summary: { type: 'string', description: 'One sentence on what belongs in the topic and what does not' },
        },
        required: ['name', 'summary'],
      },
    },
  },
  required: ['themes'],
};

const ASSIGN_SCHEMA = {
  type: 'object',
  properties: {
    assignments: {
      type: 'array',
      description: 'One entry for each topic that receives at least one video',
      items: {
        type: 'object',
        properties: {
          theme: { type: 'integer', description: 'Topic number' },
          videos: { type: 'array', items: { type: 'integer' }, description: 'Indexes of the videos assigned to the topic' },
        },
        required: ['theme', 'videos'],
      },
    },
  },
  required: ['assignments'],
};

const BATCH = 120;

/**
 * Groups videos into broad topics, in two phases so catalogs of any size fit:
 * 1) the model finds the topics by reading every title;
 * 2) it assigns videos to topics in batches, using title, tags and the start of the description.
 * Returns [{ name, summary, videos: [indexes] }].
 */
export async function groupVideos(settings, videos, onProgress) {
  const lang = LANGUAGES[settings.language] || 'English';
  const context = settings.channelContext || 'not specified';

  // ---- phase 1: find the topics
  onProgress?.(t('progress_themes'));
  const titleLen = videos.length > 1500 ? 70 : 110;
  const titles = videos.map((v) => `- ${oneLine(v.title, titleLen)}`).join('\n');
  const themePrompt = `Channel context: ${context}
Number of videos: ${videos.length}

Below are the titles of every video on the channel. Identify the broad topics to organize them into.

Rules:
- A topic is coherent: someone who watches one video in the topic would want to watch the others too.
- Each topic should ideally contain at least ${settings.minSize} videos. Avoid tiny topics, but do not merge subjects that are unrelated from the viewer's point of view.
- Base topics on what the videos are about, not on their format.
- Topic name: short (at most 6 words) and descriptive. Summary: one sentence clarifying what belongs in the topic and what does not.
- Write topic names and summaries in ${lang}.

Titles:
${titles}

Return the topics in the requested structured format.`;

  const themeReq = {
    system: SYSTEM_THEMES,
    schema: THEMES_SCHEMA,
    maxTokens: 16000,
    valid: (r) => Array.isArray(r.themes) && r.themes.length > 0,
    phase: t('phase_themes'),
  };
  let found;
  try {
    found = await ask(settings, { ...themeReq, prompt: themePrompt });
  } catch (err) {
    if (!err.truncated) throw err;
    try {
      found = await ask(settings, {
        ...themeReq,
        prompt: `${themePrompt}\n\nIdentify at most 40 topics and keep each summary under 15 words.`,
      });
    } catch (e) {
      if (!e.truncated) throw e;
      throw new Error(t('llm_themes_too_long'));
    }
  }

  const themes = found.themes
    .filter((th) => th && th.name)
    .slice(0, 80)
    .map((th) => ({ name: String(th.name).slice(0, 80), summary: String(th.summary || ''), videos: [] }));
  if (!themes.length) throw new Error(t('llm_no_themes'));

  // ---- phase 2: assign videos to topics, in batches
  const themeList = themes.map((th, i) => `${i}. ${th.name}: ${th.summary}`).join('\n');
  let done = 0;

  const assignBatch = async (start, size = BATCH) => {
    const slice = videos.slice(start, start + size);
    const lines = slice
      .map((v, i) => `${i} | ${oneLine(v.title, 120)} | ${oneLine(v.tags.slice(0, 6).join(', '), 90)} | ${oneLine(v.description, 150)}`)
      .join('\n');
    const prompt = `Channel context: ${context}

Available topics (number. name: summary):
${themeList}

Assign each video to the most suitable topic. If a video does not clearly fit any topic, leave it unassigned.

Videos (format: index | title | tags | start of description):
${lines}

Return the assignments in the requested structured format, using topic numbers and video indexes.`;

    let data;
    try {
      data = await ask(settings, {
        system: SYSTEM_THEMES,
        prompt,
        schema: ASSIGN_SCHEMA,
        maxTokens: 8000,
        valid: (r) => Array.isArray(r.assignments),
        phase: t('phase_assign'),
      });
    } catch (err) {
      if (!err.truncated) throw err;
      if (slice.length <= 5) throw new Error(t('llm_truncated', { phase: t('phase_assign') }));
      const half = Math.ceil(slice.length / 2);
      await assignBatch(start, half);
      await assignBatch(start + half, slice.length - half);
      return;
    }

    const seen = new Set();
    for (const a of data.assignments) {
      const th = themes[Number(a?.theme)];
      if (!th || !Array.isArray(a.videos)) continue;
      for (const raw of a.videos) {
        const i = Number(raw);
        if (Number.isInteger(i) && i >= 0 && i < slice.length && !seen.has(i)) {
          seen.add(i);
          th.videos.push(start + i);
        }
      }
    }
    done += slice.length;
    onProgress?.(t('progress_assign', { done, total: videos.length }));
  };

  // three batches at a time: faster, without overloading the API
  const queue = [];
  for (let start = 0; start < videos.length; start += BATCH) queue.push(start);
  const workers = Array.from({ length: Math.min(3, queue.length) }, async () => {
    while (queue.length) await assignBatch(queue.shift());
  });
  await Promise.all(workers);

  const result = themes.filter((th) => th.videos.length);
  if (!result.length) throw new Error(t('llm_none_assigned'));
  return result;
}

// ------------------------------------------------------------------ SEO

const SEO_SCHEMA = {
  type: 'object',
  properties: {
    playlists: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          key: { type: 'string', description: 'The playlist key, exactly as received' },
          title: { type: 'string' },
          description: { type: 'string' },
        },
        required: ['key', 'title', 'description'],
      },
    },
  },
  required: ['playlists'],
};

/**
 * Writes SEO titles and descriptions.
 * items: [{ key, theme, summary, videos: [titles in order] }] -> [{ key, title, description }]
 */
export async function writeSeo(settings, items) {
  const lang = LANGUAGES[settings.language] || 'English';
  const system =
    'You are an SEO expert for YouTube and Google. You write playlist titles and descriptions that rank well in search and make people want to watch the videos in sequence.';

  const results = [];
  const run = async (batch, maxTokens = 8000) => {
    const prompt = `Channel context: ${settings.channelContext || 'not specified'}
Language: write every title and description in ${lang}.

For each playlist, write a title and a description following these rules:
- Title: at most 70 characters, with the main keyword at the start, phrased the way a person would search for it on YouTube or Google. No shouty capitals, no clickbait, no emoji.
- Description: 600 to 1200 characters. The first two sentences (about 150 characters) contain the main keyword and say clearly what the viewer will find, because they are what search results show.
- Then one or two paragraphs explaining what the playlist shows or teaches, mentioning the topics of the videos and naturally using secondary keywords, synonyms and questions people type into search.
- End with an invitation to watch the playlist in the suggested order or to subscribe to the channel.
- No keyword lists, no hashtags, no links, no < or > characters.
- Every playlist must have a different title.

Playlists:
${JSON.stringify(batch, null, 1)}

Return each playlist's title and description in the requested structured format, together with its key.`;

    const keys = new Set(batch.map((b) => b.key));
    let data;
    try {
      data = await ask(settings, {
        system,
        prompt,
        schema: SEO_SCHEMA,
        maxTokens,
        valid: (r) => Array.isArray(r.playlists) && r.playlists.some((p) => keys.has(String(p?.key))),
        phase: t('phase_seo'),
      });
    } catch (err) {
      if (!err.truncated) throw err;
      if (batch.length > 1) {
        const half = Math.ceil(batch.length / 2);
        await run(batch.slice(0, half));
        await run(batch.slice(half));
        return;
      }
      if (maxTokens < 16000) return run(batch, 16000);
      throw new Error(t('llm_truncated', { phase: t('phase_seo') }));
    }
    for (const p of data.playlists) {
      if (p && keys.has(String(p.key))) {
        results.push({ key: String(p.key), title: String(p.title || ''), description: String(p.description || '') });
      }
    }
  };

  for (let i = 0; i < items.length; i += 4) await run(items.slice(i, i + 4));
  return results;
}
