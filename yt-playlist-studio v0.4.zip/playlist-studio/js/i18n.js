// Interface translations. Strings can be plain text with {placeholders} or functions of the variables.

const plural = (n, one, many) => (n === 1 ? one : many);

const STR = {
  en: {
    ui_language: 'Interface language',

    step1_title: 'Connect your channel',
    connect_hint_default: 'Sign in with the Google account that owns the channel.',
    connect_hint_connected: 'Connected to {name}.',
    btn_connect: 'Connect YouTube',
    btn_disconnect: 'Disconnect',

    step2_title: 'Set the rules',
    grp_credentials: 'Credentials',
    f_clientId: 'Google OAuth client ID',
    f_redirect: 'Redirect URI to authorize in Google Cloud',
    btn_copy: 'Copy',
    copied: 'Copied',
    f_provider: 'AI provider',
    f_anthropicKey: 'Anthropic API key',
    f_openaiKey: 'OpenAI API key',
    f_geminiKey: 'Gemini API key',
    key_note: 'Stored only in this browser.',
    f_model: 'Model',

    grp_composition: 'Playlist composition',
    f_minSize: 'Minimum videos',
    f_maxSize: 'Maximum videos',
    size_note: 'Topics below the minimum are skipped; topics above the maximum keep only the videos with the best retention.',
    f_metric: 'Retention criterion',
    metric_balanced: 'Balanced: percentage viewed and watch time',
    metric_pct: 'Average percentage viewed',
    metric_duration: 'Average view duration',
    f_period: 'Metrics period',
    period_90: 'Last 90 days',
    period_365: 'Last 12 months',
    period_lifetime: 'Since the channel was created',
    f_minDuration: 'Skip videos up to (seconds)',
    minDuration_note: '60 skips most Shorts; 0 skips nothing.',
    f_onlyPublic: 'Use public videos only',

    grp_text: 'Text and publishing',
    f_language: 'Language of titles and descriptions',
    lang_it: 'Italian',
    lang_en: 'English',
    lang_es: 'Spanish',
    lang_fr: 'French',
    lang_de: 'German',
    lang_pt: 'Portuguese',
    f_context: 'What your channel is about',
    context_ph: 'e.g. quick recipes for busy people, audience aged 25-45',
    context_note: 'Helps choose topics and keywords.',
    f_privacy: 'Visibility of new playlists',
    privacy_public: 'Public',
    privacy_unlisted: 'Unlisted',
    privacy_private: 'Private',
    btn_save_settings: 'Save settings',
    saved: 'Saved',

    step3_title: 'Analyze',
    analyze_hint: 'Reads videos and metrics and proposes playlists. Nothing changes on the channel until you confirm.',
    btn_analyze: 'Analyze channel',

    managed_title: 'Managed playlists',
    btn_managed_show: 'Show list',
    btn_managed_hide: 'Close list',
    loading: 'Loading…',
    managed_note:
      'The extension can reorder and edit the selected playlists; all others are never touched. Only add playlists created with Playlist Studio, for example with an earlier version.',
    managed_hint_n: ({ n }) =>
      `${plural(n, '1 playlist', `${n} playlists`)} can be updated by the extension. All others are never touched.`,
    managed_hint_0: 'None yet. Playlists created by the extension appear here, and they are the only ones it can update.',
    managed_empty: 'The channel has no playlists yet.',
    managed_videos: ({ n }) => plural(n, '1 video', `${n} videos`),

    empty_title: 'Playlists built on what your audience actually watches',
    empty_text:
      'Connect your channel, check the rules and run the analysis. Each topic becomes a playlist with the most engaging videos first, and titles and descriptions written for search.',

    preview_title: 'Proposed playlists',
    btn_reset: 'Discard proposal',
    btn_create: 'Create playlists on YouTube',
    btn_apply: 'Apply on YouTube',
    btn_resume: 'Resume',

    err_need_channel_first: 'Connect your channel first to see its playlists.',
    err_need_key: 'Enter the {provider} API key in the credentials before running the analysis.',
    confirm_replace: 'The current proposal will be replaced. Playlists already created on YouTube stay where they are. Continue?',
    log_uploads: 'Reading the list of uploaded videos…',
    log_uploads_n: 'Reading the list of uploaded videos… {n}',
    log_uploads_done: ({ n }) => `${plural(n, '1 video', `${n} videos`)} found on the channel.`,
    log_details: 'Reading video details…',
    log_details_n: 'Reading video details… {n} of {total}',
    log_filtered: '{kept} videos considered, {skipped} skipped for visibility or length.',
    err_not_enough: 'Not enough videos to build a playlist with the current rules.',
    log_metrics: 'Reading retention metrics from YouTube Analytics…',
    log_metrics_done: 'Retention metrics available for {n} of {total} videos.',
    log_grouping: 'Grouping videos into topics…',
    progress_themes: "Finding the channel's topics…",
    progress_assign: 'Assigning videos to topics… {done} of {total}',
    log_themes_done: ({ n }) => `${plural(n, '1 topic', `${n} topics`)} found.`,
    log_matching: 'Comparing the proposal with playlists already created by the extension…',
    log_matching_done: '{upd} proposals update existing playlists, {nw} are new.',
    log_seo: 'Writing search-optimized titles and descriptions…',
    log_seo_done: 'Titles and descriptions ready.',
    warn_no_themes: 'No topic reaches {n} videos. Try lowering the minimum or describing the channel in more detail.',
    log_ready: 'Proposal ready: review and edit it before applying it on YouTube.',

    summary: ({ sel, total, nNew, nUpd, videos }) =>
      `${sel} of ${total} playlists selected${nUpd ? ` (${nNew} new, ${nUpd} to update)` : ''}, ${plural(videos, '1 video', `${videos} videos`)} in total.`,
    summary_quota: ' These changes cost about {q} of {daily} daily quota units.',
    summary_quota_over: ' Work will stop when the quota runs out, and you can resume it the next day.',
    summary_unmatched: ({ n }) =>
      n === 1
        ? ' One other managed playlist matches no topic and stays unchanged.'
        : ` ${n} other managed playlists match no topic and stay unchanged.`,

    counter_title: '{n} of 150 characters, ideally up to 70',
    counter_desc: '{n} of 5000 characters, ideally 600 to 1200',
    dup_title: 'A playlist with this title already exists on the channel.',
    badge_updated: 'Updated, open on YouTube',
    badge_update: 'Updates an existing playlist',
    badge_created: 'Created, open on YouTube',
    badge_partial: 'Partly created: {a} of {b} videos added',
    badge_new: 'New playlist',
    note_below_min: 'Below the minimum of {n} videos.',
    note_above_max: 'Above the maximum of {n} videos.',
    f_title: 'Title',
    f_new_title: 'New title',
    f_desc: 'Description',
    f_new_desc: 'New description',
    btn_regen: 'Rewrite title and description',
    regen_busy: 'Rewriting…',
    cur_title: 'Current title',
    cur_desc: 'Current description',
    no_desc: 'No description',
    chk_update_text: 'Also rewrite title and description',
    keep_text_note: 'Title and description stay unchanged, so the playlist keeps the search ranking it has already earned.',
    vid_meta: '{pct}% viewed on average, {dur} average view duration out of {len}, {views} views',
    vid_meta_nodata: 'No retention data in this period, {views} views',
    chip_new: 'New',
    aria_up: 'Move up',
    aria_down: 'Move down',
    aria_remove: 'Remove from playlist',
    head_count: ({ n }) => `${plural(n, '1 video', `${n} videos`)}, most engaging first`,
    diff_add: '{n} to add',
    diff_remove: '{n} to remove',
    diff_moves: ({ n }) => plural(n, '1 move', `${n} moves`),
    diff_none: 'No changes to the videos',
    removed_title: 'Will be removed from this playlist (they stay on the channel):',
    btn_resort: 'Sort by retention',
    reserve_summary: ({ n }) => `${plural(n, '1 more video', `${n} more videos`)} from this topic`,
    btn_add: 'Add',
    include: 'Include',
    no_playlists: 'No playlists to propose with the current rules.',
    excluded_summary: ({ g, v }) => `Left out: ${plural(g, '1 group', `${g} groups`)}, ${plural(v, '1 video', `${v} videos`)}`,
    excl_below_min: '{n} videos, below the minimum of {min}',
    excl_unassigned: 'Videos not assigned to any topic',
    excl_count: ({ n }) => plural(n, '1 video', `${n} videos`),
    confirm_discard: 'Discard the proposal? Playlists already created on YouTube stay where they are.',
    err_no_title: 'The playlist for the topic "{theme}" has no title.',
    confirm_apply: ({ nNew, nUpd, q, daily }) => {
      const parts = [];
      if (nNew) parts.push(`create ${plural(nNew, '1 playlist', `${nNew} playlists`)}`);
      if (nUpd) parts.push(`update ${plural(nUpd, '1 existing playlist', `${nUpd} existing playlists`)}`);
      return `This will ${parts.join(' and ')}, for about ${q} of ${daily} daily quota units. Continue?`;
    },
    log_creating: 'Creating "{title}"…',
    log_creating_n: 'Creating "{title}": adding video {i} of {n}…',
    log_created: '"{title}" created with {n} videos.',
    log_updating: 'Updating "{title}"…',
    log_updating_n: 'Updating "{title}": change {i} of {n}…',
    log_updated: '"{title}" updated with {n} changes.',
    log_already: '"{title}" was already in order.',
    log_all_done: 'Done: all selected changes are on YouTube.',
    log_quota_resume: 'Progress so far is saved. Tomorrow press "Resume" and the extension will pick up where it left off.',

    err_no_client: 'Enter the Google OAuth client ID in the settings and save them.',
    err_silent: 'A new Google sign-in is needed.',
    err_auth_incomplete:
      "Google sign-in wasn't completed. If the window showed an error, check the client ID and redirect URI in your Google Cloud project.",
    err_access_denied: 'Access denied. If the Google Cloud app is in testing mode, add your account to the test users.',
    err_auth_failed: 'Google sign-in failed: {error}',
    err_no_token: "Google didn't return an access token.",

    yt_quota: 'The YouTube Data API daily quota is used up. It resets at midnight Pacific Time.',
    yt_forbidden: 'YouTube refused the operation. Make sure you signed in with the account that owns the channel.',
    yt_insufficient: 'Missing permissions: disconnect and reconnect the channel, accepting all the requested permissions.',
    yt_api_disabled: 'An API is not enabled in your Google Cloud project. Enable both YouTube Data API v3 and YouTube Analytics API.',
    yt_title_required: 'Every playlist needs a title.',
    yt_invalid_snippet: 'YouTube rejected the playlist title or description (check length and characters).',
    yt_playlist_not_found: 'A playlist to update no longer exists on YouTube. Run the analysis again.',
    yt_item_not_found: 'A playlist item changed in the meantime. Try again: the extension will recalculate the changes.',
    yt_video_not_found: 'One of the videos is no longer available on the channel. Run the analysis again.',
    yt_generic: 'YouTube error ({status}): {msg}',
    yt_no_channel:
      'No YouTube channel is linked to this account. If the channel belongs to a Brand Account, disconnect and reconnect choosing the right channel.',

    phase_themes: 'Finding topics',
    phase_assign: 'Assigning videos to topics',
    phase_seo: 'Writing titles and descriptions',
    llm_no_key: 'Enter the {provider} API key in the settings.',
    llm_bad_key: 'Invalid {provider} API key. Check it in the settings.',
    llm_model_not_found: 'Model "{model}" not found. Check the model name in the settings.',
    llm_no_credit: 'Your {provider} account has no credit left or has reached its spending limit.',
    llm_rate: 'Too many requests to {provider}. Wait a minute and try again.',
    llm_error: '{phase}: AI model error ({status}): {msg}',
    llm_bad_format: "{phase}: the model didn't return data in the expected format. Try again.",
    llm_refused: '{phase}: the model declined the request. Try again or switch model.',
    llm_truncated: "{phase}: the model's answer was cut off. Try again.",
    llm_themes_too_long:
      "Finding topics: the model's answer is too long even in short form. Add context about the channel and try again.",
    llm_no_themes: 'The model found no topics. Add context about the channel and try again.',
    llm_none_assigned: "The model didn't assign any video to a topic. Try again.",
  },

  it: {
    ui_language: "Lingua dell'interfaccia",

    step1_title: 'Collega il canale',
    connect_hint_default: "Accedi con l'account Google proprietario del canale.",
    connect_hint_connected: 'Collegato al canale {name}.',
    btn_connect: 'Collega YouTube',
    btn_disconnect: 'Scollega',

    step2_title: 'Imposta le regole',
    grp_credentials: 'Credenziali',
    f_clientId: 'Client ID OAuth di Google',
    f_redirect: 'URI di reindirizzamento da autorizzare in Google Cloud',
    btn_copy: 'Copia',
    copied: 'Copiato',
    f_provider: 'Fornitore di IA',
    f_anthropicKey: 'Chiave API di Anthropic',
    f_openaiKey: 'Chiave API di OpenAI',
    f_geminiKey: 'Chiave API di Gemini',
    key_note: 'Resta salvata solo in questo browser.',
    f_model: 'Modello',

    grp_composition: 'Composizione delle playlist',
    f_minSize: 'Video minimi',
    f_maxSize: 'Video massimi',
    size_note: 'I temi sotto il minimo vengono esclusi; quelli sopra il massimo tengono solo i video con più retention.',
    f_metric: 'Criterio di retention',
    metric_balanced: 'Bilanciato: percentuale vista e durata di visione',
    metric_pct: 'Percentuale media vista',
    metric_duration: 'Durata media di visione',
    f_period: 'Periodo delle metriche',
    period_90: 'Ultimi 90 giorni',
    period_365: 'Ultimi 12 mesi',
    period_lifetime: 'Dalla nascita del canale',
    f_minDuration: 'Escludi video che durano fino a (secondi)',
    minDuration_note: '60 esclude la maggior parte degli Shorts; 0 non esclude nulla.',
    f_onlyPublic: 'Usa solo video pubblici',

    grp_text: 'Testi e pubblicazione',
    f_language: 'Lingua di titoli e descrizioni',
    lang_it: 'Italiano',
    lang_en: 'Inglese',
    lang_es: 'Spagnolo',
    lang_fr: 'Francese',
    lang_de: 'Tedesco',
    lang_pt: 'Portoghese',
    f_context: 'Di cosa parla il canale',
    context_ph: 'Es. ricette veloci per chi lavora, pubblico italiano 25-45 anni',
    context_note: 'Aiuta a scegliere temi e parole chiave.',
    f_privacy: 'Visibilità delle nuove playlist',
    privacy_public: 'Pubblica',
    privacy_unlisted: 'Non in elenco',
    privacy_private: 'Privata',
    btn_save_settings: 'Salva impostazioni',
    saved: 'Salvate',

    step3_title: 'Analizza',
    analyze_hint: 'Legge video e metriche e propone le playlist. Sul canale non cambia nulla finché non confermi.',
    btn_analyze: 'Analizza il canale',

    managed_title: 'Playlist gestite',
    btn_managed_show: 'Mostra elenco',
    btn_managed_hide: 'Chiudi elenco',
    loading: 'Carico…',
    managed_note:
      "Le playlist selezionate possono essere riordinate e modificate dall'estensione; tutte le altre non vengono mai toccate. Aggiungi solo playlist create con Playlist Studio, per esempio con una versione precedente.",
    managed_hint_n: ({ n }) =>
      `${n} playlist ${plural(n, 'può essere aggiornata', 'possono essere aggiornate')} dall'estensione. Tutte le altre non vengono mai toccate.`,
    managed_hint_0: "Nessuna per ora. Le playlist create dall'estensione finiscono qui e sono le uniche che potrà aggiornare.",
    managed_empty: 'Il canale non ha ancora playlist.',
    managed_videos: ({ n }) => `${n} video`,

    empty_title: 'Playlist costruite su ciò che il pubblico guarda davvero',
    empty_text:
      "Collega il canale, controlla le regole e avvia l'analisi. Ogni tema diventa una playlist con i video che trattengono di più in testa, e titoli e descrizioni scritti per la ricerca.",

    preview_title: 'Playlist proposte',
    btn_reset: 'Scarta proposta',
    btn_create: 'Crea playlist su YouTube',
    btn_apply: 'Applica su YouTube',
    btn_resume: 'Riprendi il lavoro',

    err_need_channel_first: 'Collega prima il canale per vedere le sue playlist.',
    err_need_key: "Inserisci la chiave API di {provider} nelle credenziali prima di avviare l'analisi.",
    confirm_replace: 'La proposta attuale verrà sostituita. Le playlist già create su YouTube restano dove sono. Continuare?',
    log_uploads: "Leggo l'elenco dei video caricati…",
    log_uploads_n: "Leggo l'elenco dei video caricati… {n}",
    log_uploads_done: '{n} video trovati sul canale.',
    log_details: 'Leggo i dettagli dei video…',
    log_details_n: 'Leggo i dettagli dei video… {n} di {total}',
    log_filtered: '{kept} video considerati, {skipped} esclusi per visibilità o durata.',
    err_not_enough: 'Non ci sono abbastanza video per comporre una playlist con le regole attuali.',
    log_metrics: 'Leggo le metriche di retention da YouTube Analytics…',
    log_metrics_done: 'Metriche di retention disponibili per {n} video su {total}.',
    log_grouping: 'Raggruppo i video per macro-tematiche…',
    progress_themes: 'Individuo i temi del canale…',
    progress_assign: 'Assegno i video ai temi… {done} di {total}',
    log_themes_done: ({ n }) => `${n} ${plural(n, 'tema individuato', 'temi individuati')}.`,
    log_matching: "Confronto la proposta con le playlist già create dall'estensione…",
    log_matching_done: '{upd} proposte aggiornano playlist esistenti, {nw} sono nuove.',
    log_seo: 'Scrivo titoli e descrizioni ottimizzati per la ricerca…',
    log_seo_done: 'Titoli e descrizioni pronti.',
    warn_no_themes: 'Nessun tema raggiunge {n} video. Prova ad abbassare il minimo o a descrivere meglio il canale.',
    log_ready: 'Proposta pronta: rivedila e modificala prima di applicarla su YouTube.',

    summary: ({ sel, total, nNew, nUpd, videos }) =>
      `${sel} playlist selezionate su ${total}${nUpd ? ` (${nNew} ${plural(nNew, 'nuova', 'nuove')}, ${nUpd} da aggiornare)` : ''}, ${videos} video in totale.`,
    summary_quota: ' Le modifiche costano circa {q} unità di quota su {daily} giornaliere.',
    summary_quota_over: ' Il lavoro si fermerà a quota esaurita e potrai riprenderlo il giorno dopo.',
    summary_unmatched: ({ n }) =>
      n === 1
        ? " Un'altra playlist gestita non corrisponde a nessun tema e resta invariata."
        : ` Altre ${n} playlist gestite non corrispondono a nessun tema e restano invariate.`,

    counter_title: '{n} di 150 caratteri, ideale entro 70',
    counter_desc: '{n} di 5000 caratteri, ideale tra 600 e 1200',
    dup_title: 'Sul canale esiste già una playlist con questo titolo.',
    badge_updated: 'Aggiornata, apri su YouTube',
    badge_update: 'Aggiorna una playlist esistente',
    badge_created: 'Creata, apri su YouTube',
    badge_partial: 'Creata in parte: {a} di {b} video aggiunti',
    badge_new: 'Nuova playlist',
    note_below_min: 'Sotto il minimo di {n} video.',
    note_above_max: 'Oltre il massimo di {n} video.',
    f_title: 'Titolo',
    f_new_title: 'Nuovo titolo',
    f_desc: 'Descrizione',
    f_new_desc: 'Nuova descrizione',
    btn_regen: 'Riscrivi titolo e descrizione',
    regen_busy: 'Sto riscrivendo…',
    cur_title: 'Titolo attuale',
    cur_desc: 'Descrizione attuale',
    no_desc: 'Nessuna descrizione',
    chk_update_text: 'Riscrivi anche titolo e descrizione',
    keep_text_note: 'Titolo e descrizione restano invariati, così la playlist non perde il posizionamento già ottenuto.',
    vid_meta: '{pct}% visto in media, {dur} di visione media su {len}, {views} visualizzazioni',
    vid_meta_nodata: 'Nessun dato di retention nel periodo, {views} visualizzazioni',
    chip_new: 'Nuovo',
    aria_up: 'Sposta su',
    aria_down: 'Sposta giù',
    aria_remove: 'Togli dalla playlist',
    head_count: '{n} video, dal più coinvolgente',
    diff_add: '{n} da aggiungere',
    diff_remove: '{n} da togliere',
    diff_moves: ({ n }) => plural(n, '1 spostamento', `${n} spostamenti`),
    diff_none: 'Nessuna modifica ai video',
    removed_title: 'Verranno tolti da questa playlist (restano sul canale):',
    btn_resort: 'Riordina per retention',
    reserve_summary: ({ n }) => plural(n, 'Un altro video di questo tema', `Altri ${n} video di questo tema`),
    btn_add: 'Aggiungi',
    include: 'Includi',
    no_playlists: 'Nessuna playlist da proporre con le regole attuali.',
    excluded_summary: ({ g, v }) => `Rimasti fuori: ${plural(g, '1 gruppo', `${g} gruppi`)}, ${v} video`,
    excl_below_min: '{n} video, sotto il minimo di {min}',
    excl_unassigned: 'Video non assegnati a nessun tema',
    excl_count: '{n} video',
    confirm_discard: 'Scartare la proposta? Le playlist già create su YouTube restano dove sono.',
    err_no_title: 'La playlist del tema "{theme}" non ha un titolo.',
    confirm_apply: ({ nNew, nUpd, q, daily }) => {
      const parts = [];
      if (nNew) parts.push(`create ${nNew} playlist`);
      if (nUpd) parts.push(`aggiornate ${nUpd} playlist esistenti`);
      return `Verranno ${parts.join(' e ')}, per circa ${q} unità di quota su ${daily} giornaliere. Procedere?`;
    },
    log_creating: 'Creo "{title}"…',
    log_creating_n: 'Creo "{title}": aggiungo il video {i} di {n}…',
    log_created: '"{title}" creata con {n} video.',
    log_updating: 'Aggiorno "{title}"…',
    log_updating_n: 'Aggiorno "{title}": modifica {i} di {n}…',
    log_updated: '"{title}" aggiornata con {n} modifiche.',
    log_already: '"{title}" era già in ordine.',
    log_all_done: 'Fatto: tutte le modifiche selezionate sono su YouTube.',
    log_quota_resume: 'Il lavoro fatto finora è salvato. Domani premi "Riprendi il lavoro" e l\'estensione ripartirà da dove si è fermata.',

    err_no_client: 'Inserisci il Client ID OAuth di Google nelle impostazioni e salvale.',
    err_silent: 'Serve un nuovo accesso a Google.',
    err_auth_incomplete:
      'Accesso a Google non completato. Se la finestra mostrava un errore, controlla Client ID e URI di reindirizzamento nel progetto Google Cloud.',
    err_access_denied: "Accesso negato. Se l'app Google Cloud è in modalità test, aggiungi il tuo account tra gli utenti di test.",
    err_auth_failed: 'Accesso a Google non riuscito: {error}',
    err_no_token: 'Google non ha restituito un token di accesso.',

    yt_quota:
      'Quota giornaliera della YouTube Data API esaurita. Si azzera a mezzanotte, ora del Pacifico (le 9 del mattino in Italia).',
    yt_forbidden: "YouTube ha negato l'operazione. Verifica di aver effettuato l'accesso con l'account proprietario del canale.",
    yt_insufficient: 'Permessi insufficienti: scollega e ricollega il canale accettando tutte le autorizzazioni richieste.',
    yt_api_disabled: "Un'API non è attiva nel progetto Google Cloud. Attiva sia YouTube Data API v3 sia YouTube Analytics API.",
    yt_title_required: 'Ogni playlist deve avere un titolo.',
    yt_invalid_snippet: 'YouTube ha rifiutato titolo o descrizione della playlist (controlla lunghezza e caratteri).',
    yt_playlist_not_found: "Una playlist da aggiornare non esiste più su YouTube. Rilancia l'analisi.",
    yt_item_not_found: "Un elemento della playlist è cambiato nel frattempo. Riprova: l'estensione ricalcolerà le modifiche.",
    yt_video_not_found: "Uno dei video non è più disponibile sul canale. Rilancia l'analisi.",
    yt_generic: 'Errore YouTube ({status}): {msg}',
    yt_no_channel:
      'Nessun canale YouTube associato a questo account. Se il canale appartiene a un Account Brand, scollega e ricollega scegliendo il canale giusto.',

    phase_themes: 'Individuazione dei temi',
    phase_assign: 'Assegnazione dei video ai temi',
    phase_seo: 'Scrittura di titoli e descrizioni',
    llm_no_key: 'Inserisci la chiave API di {provider} nelle impostazioni.',
    llm_bad_key: 'Chiave API di {provider} non valida. Controllala nelle impostazioni.',
    llm_model_not_found: 'Modello "{model}" non trovato. Controlla il nome del modello nelle impostazioni.',
    llm_no_credit: 'Il tuo account {provider} ha finito il credito o ha raggiunto il limite di spesa.',
    llm_rate: 'Troppe richieste a {provider}. Aspetta un minuto e riprova.',
    llm_error: '{phase}: errore del modello di linguaggio ({status}): {msg}',
    llm_bad_format: '{phase}: il modello non ha restituito dati nel formato atteso. Riprova.',
    llm_refused: '{phase}: il modello ha rifiutato la richiesta. Riprova o cambia modello.',
    llm_truncated: '{phase}: la risposta del modello è stata troncata. Riprova.',
    llm_themes_too_long:
      'Individuazione dei temi: la risposta del modello è troppo lunga anche in forma sintetica. Aggiungi contesto sul canale e riprova.',
    llm_no_themes: 'Il modello non ha individuato temi. Aggiungi contesto sul canale e riprova.',
    llm_none_assigned: 'Il modello non ha assegnato alcun video ai temi. Riprova.',
  },
};

let lang = 'en';

export function detectLang() {
  const ui = (globalThis.chrome?.i18n?.getUILanguage?.() || globalThis.navigator?.language || 'en').toLowerCase();
  return ui.startsWith('it') ? 'it' : 'en';
}

export function setLang(value) {
  lang = value === 'it' ? 'it' : 'en';
  if (globalThis.document) document.documentElement.lang = lang;
}

export const getLang = () => lang;
export const locale = () => (lang === 'it' ? 'it-IT' : 'en-US');

export function t(key, vars = {}) {
  const entry = STR[lang][key] ?? STR.en[key];
  if (entry == null) return key;
  if (typeof entry === 'function') return entry(vars);
  return entry.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? `{${k}}`));
}

/** Applies translations to elements marked with data-i18n, data-i18n-placeholder, data-i18n-aria. */
export function applyStatic(root = document) {
  root.querySelectorAll('[data-i18n]').forEach((el) => (el.textContent = t(el.dataset.i18n)));
  root.querySelectorAll('[data-i18n-placeholder]').forEach((el) => (el.placeholder = t(el.dataset.i18nPlaceholder)));
  root.querySelectorAll('[data-i18n-aria]').forEach((el) => el.setAttribute('aria-label', t(el.dataset.i18nAria)));
}

// Parity check helper (used in tests): keys present in one language but not the other.
export function missingKeys() {
  const en = Object.keys(STR.en);
  const it = Object.keys(STR.it);
  return { missingInIt: en.filter((k) => !it.includes(k)), missingInEn: it.filter((k) => !en.includes(k)) };
}
