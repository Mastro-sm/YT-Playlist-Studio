/**
 * Sorts video ids from the highest retention score to the lowest.
 * metric: "pct" (average percentage viewed), "duration" (average view duration),
 * "balanced" (geometric mean of the two, normalized within the group).
 * Videos without data go last; ties are broken by views.
 */
export function sortByScore(ids, byId, metric) {
  const withData = ids.map((id) => byId[id]).filter((v) => v && v.pct != null);
  const maxPct = Math.max(1e-9, ...withData.map((v) => v.pct));
  const maxDur = Math.max(1e-9, ...withData.map((v) => v.dur || 0));

  const score = (id) => {
    const v = byId[id];
    if (!v || v.pct == null) return -1;
    if (metric === 'pct') return v.pct;
    if (metric === 'duration') return v.dur || 0;
    return Math.sqrt((v.pct / maxPct) * ((v.dur || 0) / maxDur));
  };

  return [...ids].sort((a, b) => score(b) - score(a) || (byId[b]?.views || 0) - (byId[a]?.views || 0));
}

export function buildPlan(themes, videos, metrics, settings) {
  const byId = {};
  for (const v of videos) {
    const m = metrics.get(v.id);
    byId[v.id] = {
      id: v.id,
      title: v.title,
      thumb: v.thumb,
      durationSec: v.durationSec,
      views: m ? m.views : v.views,
      pct: m ? m.pct : null,
      dur: m ? m.dur : null,
    };
  }

  const stamp = Date.now().toString(36);
  const playlists = [];
  const excluded = [];
  const assigned = new Set();

  themes.forEach((t, ti) => {
    const ids = t.videos.map((i) => videos[i]?.id).filter(Boolean);
    ids.forEach((id) => assigned.add(id));
    if (!ids.length) return;
    const sorted = sortByScore(ids, byId, settings.metric);

    if (sorted.length < settings.minSize) {
      excluded.push({ theme: t.name, reason: { type: 'belowMin', n: sorted.length, min: settings.minSize }, videos: sorted });
      return;
    }
    playlists.push({
      key: `p${ti}_${stamp}`,
      theme: t.name,
      summary: t.summary,
      include: true,
      title: t.name,
      description: '',
      videos: sorted.slice(0, settings.maxSize),
      reserve: sorted.slice(settings.maxSize),
      mode: 'create',
      createdId: null,
      addedCount: 0,
    });
  });

  const unassigned = videos.map((v) => v.id).filter((id) => !assigned.has(id));
  if (unassigned.length) {
    excluded.push({ theme: null, unassigned: true, reason: { type: 'unassigned', n: unassigned.length }, videos: unassigned });
  }

  playlists.sort((a, b) => b.videos.length + b.reserve.length - (a.videos.length + a.reserve.length));

  return {
    createdAt: Date.now(),
    metric: settings.metric,
    videosById: byId,
    playlists,
    excluded,
    existingTitles: [],
  };
}

/**
 * Matches proposed playlists to the extension's managed playlists by shared videos.
 * managed: [{ id, title, description, items: [{ itemId, videoId }] }]
 * Returns the titles of managed playlists left unmatched (they will not be touched).
 */
export function matchManaged(playlists, managed) {
  const pairs = [];
  for (const p of playlists) {
    const theme = new Set([...p.videos, ...p.reserve]);
    for (const m of managed) {
      const existing = new Set(m.items.map((i) => i.videoId));
      if (!existing.size) continue;
      let common = 0;
      for (const v of existing) if (theme.has(v)) common++;
      const score = common / Math.min(theme.size, existing.size);
      if (common >= 2 && score >= 0.5) pairs.push({ p, m, score, common });
    }
  }
  pairs.sort((a, b) => b.score - a.score || b.common - a.common);

  const usedP = new Set();
  const usedM = new Set();
  for (const { p, m } of pairs) {
    if (usedP.has(p.key) || usedM.has(m.id)) continue;
    usedP.add(p.key);
    usedM.add(m.id);
    Object.assign(p, {
      mode: 'update',
      targetId: m.id,
      existingTitle: m.title,
      existingDescription: m.description,
      existingItems: m.items.map((i) => i.videoId),
      updateText: false,
      textDone: false,
      done: false,
    });
  }
  return managed.filter((m) => !usedM.has(m.id)).map((m) => m.title);
}

/** Indexes of a longest increasing subsequence. */
function longestIncreasing(values) {
  const tails = [];
  const tailIdx = [];
  const prev = new Array(values.length).fill(-1);
  values.forEach((x, i) => {
    let lo = 0;
    let hi = tails.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (tails[mid] < x) lo = mid + 1;
      else hi = mid;
    }
    tails[lo] = x;
    tailIdx[lo] = i;
    prev[i] = lo > 0 ? tailIdx[lo - 1] : -1;
  });
  const out = new Set();
  let k = tails.length ? tailIdx[tails.length - 1] : -1;
  while (k !== -1) {
    out.add(k);
    k = prev[k];
  }
  return out;
}

/**
 * Computes the minimum operations to bring a playlist from its current state to the target order.
 * items: [{ itemId, videoId }] in current order; target: [videoId] in the desired order.
 * Deletions run first, then the operations in order. Videos already in the right
 * relative sequence are not moved.
 */
export function planOps(items, target) {
  const tIndex = new Map(target.map((v, i) => [v, i]));
  const seen = new Set();
  const deletes = [];
  const kept = [];
  for (const it of items) {
    if (!tIndex.has(it.videoId) || seen.has(it.videoId)) deletes.push(it);
    else {
      seen.add(it.videoId);
      kept.push({ ...it });
    }
  }

  const stableIdx = longestIncreasing(kept.map((k) => tIndex.get(k.videoId)));
  const stable = new Set([...stableIdx].map((i) => kept[i].videoId));

  const current = [...kept];
  const ops = [];
  target.forEach((videoId, i) => {
    if (stable.has(videoId)) return;
    const from = current.findIndex((c) => c.videoId === videoId);
    const entry = from >= 0 ? current.splice(from, 1)[0] : null;
    const anchor = i === 0 ? -1 : current.findIndex((c) => c.videoId === target[i - 1]);
    const position = anchor + 1;
    current.splice(position, 0, entry || { itemId: null, videoId });
    ops.push(entry ? { type: 'move', itemId: entry.itemId, videoId, position } : { type: 'insert', videoId, position });
  });

  return { deletes, ops, cost: 50 * (deletes.length + ops.length), result: current.map((c) => c.videoId) };
}
