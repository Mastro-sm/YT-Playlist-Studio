import { loadSettings } from './storage.js';
import { t } from './i18n.js';

const SCOPES = [
  'https://www.googleapis.com/auth/youtube',
  'https://www.googleapis.com/auth/yt-analytics.readonly',
];

export function redirectUri() {
  return chrome.identity.getRedirectURL();
}

async function readCache() {
  const { auth } = await chrome.storage.session.get('auth');
  if (auth && auth.expiresAt > Date.now() + 60_000) return auth.token;
  return null;
}

export async function invalidateToken() {
  await chrome.storage.session.remove('auth');
}

async function launch(interactive) {
  const { clientId } = await loadSettings();
  if (!clientId) {
    throw new Error(t('err_no_client'));
  }
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: 'token',
    redirect_uri: redirectUri(),
    scope: SCOPES.join(' '),
    include_granted_scopes: 'true',
    prompt: interactive ? 'select_account' : 'none',
  });

  let responseUrl;
  try {
    responseUrl = await chrome.identity.launchWebAuthFlow({
      url: `https://accounts.google.com/o/oauth2/v2/auth?${params}`,
      interactive,
    });
  } catch (err) {
    if (!interactive) throw new Error(t('err_silent'));
    throw new Error(t('err_auth_incomplete'));
  }

  const fragment = new URLSearchParams(new URL(responseUrl).hash.slice(1));
  const error = fragment.get('error');
  if (error) {
    if (error === 'access_denied') {
      throw new Error(t('err_access_denied'));
    }
    throw new Error(t('err_auth_failed', { error }));
  }

  const token = fragment.get('access_token');
  const expiresIn = Number(fragment.get('expires_in') || 3600);
  if (!token) throw new Error(t('err_no_token'));
  await chrome.storage.session.set({ auth: { token, expiresAt: Date.now() + expiresIn * 1000 } });
  return token;
}

/**
 * mode: "silent" (no window), "interactive" (shows the account picker),
 * "auto" (tries silently, then asks the user to sign in).
 */
export async function getToken(mode = 'auto') {
  const cached = await readCache();
  if (cached) return cached;
  if (mode === 'silent') return launch(false);
  if (mode === 'interactive') return launch(true);
  try {
    return await launch(false);
  } catch {
    return launch(true);
  }
}

export async function signOut() {
  const { auth } = await chrome.storage.session.get('auth');
  await invalidateToken();
  if (auth?.token) {
    try {
      await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(auth.token)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
    } catch {
      /* revoking is optional */
    }
  }
}
