# Playlist Studio per YouTube

*English: see [README.md](README.md).*

Estensione per Chrome che organizza i video del tuo canale in playlist. Un modello di intelligenza artificiale (Claude, ChatGPT o Gemini) raggruppa i video per tema, l'estensione ordina ogni playlist per retention e scrive titoli e descrizioni ottimizzati per la ricerca su YouTube e Google. Sul canale non cambia nulla finché non confermi l'anteprima.

L'interfaccia è disponibile in inglese e in italiano e segue la lingua di Chrome; puoi cambiarla dal menu in alto a destra.

## Cosa fa

1. Legge tutti i video caricati, escludendo se vuoi quelli non pubblici e quelli molto brevi, come gli Shorts.
2. Recupera da YouTube Analytics percentuale media vista, durata media di visione e visualizzazioni di ogni video.
3. Chiede al modello di individuare le macro-tematiche del canale dai titoli di tutti i video, e poi di assegnare ogni video a un tema a blocchi di 120, usando titoli, tag e descrizioni. Funziona con cataloghi di qualsiasi dimensione.
4. Per ogni tema: sotto il minimo (4 di default) viene escluso; sopra il massimo (10 di default) tiene solo i video con più retention. I video sono sempre ordinati dal più coinvolgente.
5. Il modello scrive titolo e descrizione SEO di ogni nuova playlist.
6. Nell'anteprima puoi modificare i testi, riordinare, togliere o aggiungere video ed escludere playlist. Poi applichi tutto con un clic.

Quando rilanci l'analisi, le playlist create in precedenza dall'estensione vengono **aggiornate** invece di essere duplicate (vedi [Aggiornare le playlist nel tempo](#aggiornare-le-playlist-nel-tempo)).

## Configurazione

### 1. Carica l'estensione in Chrome

1. Estrai l'archivio in una cartella a tua scelta.
2. Apri `chrome://extensions` e attiva **Modalità sviluppatore** in alto a destra.
3. Clicca **Carica estensione non pacchettizzata** e scegli la cartella `playlist-studio`.
4. Clicca l'icona dell'estensione: si apre Playlist Studio. Apri **Credenziali** e copia l'**URI di reindirizzamento**. È sempre `https://haahjfjoiifabhkgpapklikpiondfafa.chromiumapp.org/`, perché l'identificativo dell'estensione è fissato nel manifest e non dipende dalla cartella.

### 2. Configura Google Cloud

1. Vai su [console.cloud.google.com](https://console.cloud.google.com) e crea un progetto.
2. In **API e servizi → Libreria** attiva **YouTube Data API v3** e **YouTube Analytics API** (non la YouTube Reporting API).
3. Configura la schermata di consenso OAuth (nelle versioni recenti si chiama **Google Auth Platform**): tipo di utenti **Esterno**, un nome per l'app e la tua email.
4. Scegli come gestire l'accesso:
   - **Modalità test**: in **Pubblico** aggiungi come **utente di test** l'account Google che gestisce il canale. Google chiede di rifare l'accesso circa una volta a settimana.
   - **Produzione senza verifica**: in **Pubblico** clicca **Pubblica app**. Al login Google mostra l'avviso "app non verificata": clicca **Avanzate** e poi **Vai a …** per continuare. Per un uso personale va benissimo ed eviti l'accesso settimanale.
5. In **Credenziali** (o **Client**) crea un **ID client OAuth** di tipo **Applicazione web**. In **URI di reindirizzamento autorizzati** incolla l'URI del punto 1.
6. Copia il **Client ID** generato nelle credenziali dell'estensione.

### 3. Scegli il fornitore di IA

In **Credenziali** scegli il fornitore e incolla la sua chiave API. Le chiavi restano salvate solo nel tuo browser e vengono inviate solo al fornitore scelto.

| Fornitore | Dove creare la chiave | Modello predefinito |
|---|---|---|
| Anthropic (Claude) | [console.anthropic.com](https://console.anthropic.com) | `claude-sonnet-5` |
| OpenAI (ChatGPT) | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) | `gpt-5.5` |
| Google (Gemini) | [aistudio.google.com/apikey](https://aistudio.google.com/apikey) | `gemini-flash-latest` |

Puoi cambiare modello nel campo **Modello**. Un abbonamento a ChatGPT Plus o Gemini Advanced non include l'accesso alle API: ogni fornitore fattura le API a parte. Un'analisi completa costa in genere pochi centesimi.

Tutti e tre i fornitori restituiscono dati strutturati, quindi l'estensione non deve mai interpretare il formato della risposta.

## Uso

1. **Collega YouTube** e scegli il canale. Se il canale è un Account Brand, selezionalo nella finestra di Google.
2. Controlla le regole: minimo e massimo di video, criterio di retention, periodo delle metriche, lingua di titoli e descrizioni e una breve descrizione del canale, che migliora molto temi e parole chiave.
3. Clicca **Analizza il canale** e rivedi la proposta.
4. Clicca **Crea playlist su YouTube** (o **Applica su YouTube** se la proposta include aggiornamenti).

### Criteri di retention

- **Bilanciato** (consigliato): combina percentuale vista e durata di visione, così i video brevi non vengono favoriti solo perché è facile vederli fino in fondo.
- **Percentuale media vista**: utile se i video hanno durate simili.
- **Durata media di visione**: premia i video che generano più minuti guardati.

I video senza dati nel periodo scelto finiscono in fondo alla playlist.

## Aggiornare le playlist nel tempo

Puoi rilanciare l'analisi quando vuoi, per esempio dopo aver pubblicato nuovi video o quando la retention è cambiata. L'estensione confronta la nuova proposta con le playlist che ha creato lei stessa (le **playlist gestite**). Se una proposta ha abbastanza video in comune con una di queste, aggiorna quella playlist invece di crearne una nuova.

Nell'anteprima ogni playlist da aggiornare mostra i video da aggiungere (etichetta **Nuovo**), quelli da togliere e il numero di spostamenti. Togliere un video da una playlist non lo cancella dal canale. L'estensione calcola il numero minimo di operazioni, così consuma poca quota.

Titolo e descrizione di una playlist esistente restano invariati, così non perde il posizionamento già ottenuto. Per riscriverli, spunta **Riscrivi anche titolo e descrizione** nella scheda.

Solo le playlist gestite possono essere modificate: quelle create a mano non vengono mai toccate. Nella sezione **Playlist gestite** puoi vedere l'elenco, aggiungere le playlist create con una versione precedente dell'estensione o toglierne una se non vuoi più che venga aggiornata.

## Installare una nuova versione

Sostituisci i file nella cartella da cui hai caricato l'estensione, poi in `chrome://extensions` clicca l'icona di ricarica sulla scheda di Playlist Studio. Impostazioni, credenziali e playlist gestite vengono conservate.

Evita di rimuovere l'estensione da Chrome: cancellerebbe le impostazioni e l'elenco delle playlist gestite. Se succede, reinserisci le credenziali e riaggiungi le tue playlist in **Playlist gestite**, altrimenti la successiva analisi creerebbe dei doppioni.

## Quota di YouTube

La YouTube Data API ha una quota predefinita di 10.000 unità al giorno. Un'analisi ne consuma poche decine. Creare una playlist costa circa 50 unità più 50 per ogni video aggiunto, quindi una playlist da 10 video vale circa 550 unità: circa 18 playlist al giorno. Aggiornare costa 50 unità per ogni video aggiunto, tolto o spostato, più 50 se riscrivi titolo e descrizione. L'anteprima mostra la stima prima di confermare.

Se la quota si esaurisce a metà, il lavoro fatto resta salvato: il giorno dopo premi **Riprendi il lavoro** e l'estensione riparte da dove si era fermata, senza doppioni. La quota si azzera a mezzanotte ora del Pacifico (le 9 del mattino in Italia).

## Problemi comuni

- **Accesso bloccato / verifica di Google non completata**: il tuo account non è tra gli utenti di test dell'app Google Cloud, oppure nella finestra di accesso hai scelto un altro account. Aggiungilo in **Pubblico → Utenti di test**, oppure pubblica l'app (punto 2.4).
- **redirect_uri_mismatch**: l'URI di reindirizzamento in Google Cloud non coincide con quello mostrato nell'estensione. Ricopialo da **Credenziali**. Google può impiegare qualche minuto ad applicare la modifica.
- **API non attiva**: attiva entrambe le API del punto 2.2 nello stesso progetto del Client ID, poi aspetta un paio di minuti.
- **Nessun canale trovato**: hai scelto l'account personale invece dell'Account Brand del canale. Scollega e ricollega.
- **Chiave API non valida / modello non trovato**: controlla chiave e nome del modello per il fornitore selezionato.
- **Credito esaurito**: aggiungi credito o alza il limite di spesa nella console del fornitore.
- **Risposta troncata / formato non valido**: l'estensione riprova da sola e divide il lavoro in parti più piccole. Se il messaggio persiste, riprova o cambia modello.

## Struttura

```
manifest.json      configurazione dell'estensione (Manifest V3, ID fisso)
_locales/          nome e descrizione dell'estensione in inglese e italiano
background.js      apre il pannello al clic sull'icona
dashboard.html     interfaccia
dashboard.css      stili
js/i18n.js         traduzioni dell'interfaccia
js/auth.js         accesso a Google (OAuth tramite chrome.identity)
js/youtube.js      YouTube Data API e YouTube Analytics API
js/llm.js          raggruppamento per tema e testi SEO, per Anthropic, OpenAI e Gemini
js/planner.js      composizione, ordinamento per retention e calcolo degli aggiornamenti
js/dashboard.js    logica dell'interfaccia
js/storage.js      impostazioni, proposta salvata e playlist gestite
```
