// Al clic sull'icona apre Playlist Studio in una scheda dedicata.
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
});
